Readme

donload the file to your localhost server or webserver
navigate to ->connections
			->connection manager
			edit the database info to match the information in your radius server