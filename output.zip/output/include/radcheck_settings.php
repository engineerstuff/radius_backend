<?php
require_once(getabspath("classes/cipherer.php"));




$tdataradcheck = array();
	$tdataradcheck[".truncateText"] = true;
	$tdataradcheck[".NumberOfChars"] = 80;
	$tdataradcheck[".ShortName"] = "radcheck";
	$tdataradcheck[".OwnerID"] = "";
	$tdataradcheck[".OriginalTable"] = "radcheck";

//	field labels
$fieldLabelsradcheck = array();
$fieldToolTipsradcheck = array();
$pageTitlesradcheck = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsradcheck["English"] = array();
	$fieldToolTipsradcheck["English"] = array();
	$pageTitlesradcheck["English"] = array();
	$fieldLabelsradcheck["English"]["id"] = "Id";
	$fieldToolTipsradcheck["English"]["id"] = "";
	$fieldLabelsradcheck["English"]["username"] = "Username";
	$fieldToolTipsradcheck["English"]["username"] = "";
	$fieldLabelsradcheck["English"]["attribute"] = "Attribute";
	$fieldToolTipsradcheck["English"]["attribute"] = "";
	$fieldLabelsradcheck["English"]["op"] = "Op";
	$fieldToolTipsradcheck["English"]["op"] = "";
	$fieldLabelsradcheck["English"]["value"] = "Value";
	$fieldToolTipsradcheck["English"]["value"] = "";
	if (count($fieldToolTipsradcheck["English"]))
		$tdataradcheck[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsradcheck[""] = array();
	$fieldToolTipsradcheck[""] = array();
	$pageTitlesradcheck[""] = array();
	if (count($fieldToolTipsradcheck[""]))
		$tdataradcheck[".isUseToolTips"] = true;
}


	$tdataradcheck[".NCSearch"] = true;



$tdataradcheck[".shortTableName"] = "radcheck";
$tdataradcheck[".nSecOptions"] = 0;
$tdataradcheck[".recsPerRowPrint"] = 1;
$tdataradcheck[".mainTableOwnerID"] = "";
$tdataradcheck[".moveNext"] = 1;
$tdataradcheck[".entityType"] = 0;

$tdataradcheck[".strOriginalTableName"] = "radcheck";

	



$tdataradcheck[".showAddInPopup"] = false;

$tdataradcheck[".showEditInPopup"] = false;

$tdataradcheck[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdataradcheck[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataradcheck[".fieldsForRegister"] = array();

$tdataradcheck[".listAjax"] = false;

	$tdataradcheck[".audit"] = false;

	$tdataradcheck[".locking"] = false;

$tdataradcheck[".edit"] = true;
$tdataradcheck[".afterEditAction"] = 1;
$tdataradcheck[".closePopupAfterEdit"] = 1;
$tdataradcheck[".afterEditActionDetTable"] = "";

$tdataradcheck[".add"] = true;
$tdataradcheck[".afterAddAction"] = 1;
$tdataradcheck[".closePopupAfterAdd"] = 1;
$tdataradcheck[".afterAddActionDetTable"] = "";

$tdataradcheck[".list"] = true;

$tdataradcheck[".inlineEdit"] = true;
$tdataradcheck[".inlineAdd"] = true;
$tdataradcheck[".copy"] = true;
$tdataradcheck[".view"] = true;

$tdataradcheck[".import"] = true;

$tdataradcheck[".exportTo"] = true;

$tdataradcheck[".printFriendly"] = true;

$tdataradcheck[".delete"] = true;

$tdataradcheck[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdataradcheck[".searchSaving"] = false;
//

$tdataradcheck[".showSearchPanel"] = true;
		$tdataradcheck[".flexibleSearch"] = true;

$tdataradcheck[".isUseAjaxSuggest"] = true;

$tdataradcheck[".rowHighlite"] = true;



$tdataradcheck[".addPageEvents"] = false;

// use timepicker for search panel
$tdataradcheck[".isUseTimeForSearch"] = false;





$tdataradcheck[".allSearchFields"] = array();
$tdataradcheck[".filterFields"] = array();
$tdataradcheck[".requiredSearchFields"] = array();

$tdataradcheck[".allSearchFields"][] = "id";
	$tdataradcheck[".allSearchFields"][] = "username";
	$tdataradcheck[".allSearchFields"][] = "attribute";
	$tdataradcheck[".allSearchFields"][] = "op";
	$tdataradcheck[".allSearchFields"][] = "value";
	

$tdataradcheck[".googleLikeFields"] = array();
$tdataradcheck[".googleLikeFields"][] = "id";
$tdataradcheck[".googleLikeFields"][] = "username";
$tdataradcheck[".googleLikeFields"][] = "attribute";
$tdataradcheck[".googleLikeFields"][] = "op";
$tdataradcheck[".googleLikeFields"][] = "value";


$tdataradcheck[".advSearchFields"] = array();
$tdataradcheck[".advSearchFields"][] = "id";
$tdataradcheck[".advSearchFields"][] = "username";
$tdataradcheck[".advSearchFields"][] = "attribute";
$tdataradcheck[".advSearchFields"][] = "op";
$tdataradcheck[".advSearchFields"][] = "value";

$tdataradcheck[".tableType"] = "list";

$tdataradcheck[".printerPageOrientation"] = 0;
$tdataradcheck[".nPrinterPageScale"] = 100;

$tdataradcheck[".nPrinterSplitRecords"] = 40;

$tdataradcheck[".nPrinterPDFSplitRecords"] = 40;



$tdataradcheck[".geocodingEnabled"] = false;





$tdataradcheck[".listGridLayout"] = 3;





// view page pdf
$tdataradcheck[".isViewPagePDF"] = true;
$tdataradcheck[".nViewPagePDFScale"] = 100;

// print page pdf
$tdataradcheck[".isPrinterPagePDF"] = true;
$tdataradcheck[".nPrinterPagePDFScale"] = 100;


$tdataradcheck[".pageSize"] = 20;

$tdataradcheck[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataradcheck[".strOrderBy"] = $tstrOrderBy;

$tdataradcheck[".orderindexes"] = array();

$tdataradcheck[".sqlHead"] = "SELECT id,  	username,  	attribute,  	op,  	`value`";
$tdataradcheck[".sqlFrom"] = "FROM radcheck";
$tdataradcheck[".sqlWhereExpr"] = "";
$tdataradcheck[".sqlTail"] = "";











//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataradcheck[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataradcheck[".arrGroupsPerPage"] = $arrGPP;

$tdataradcheck[".highlightSearchResults"] = true;

$tableKeysradcheck = array();
$tableKeysradcheck[] = "id";
$tdataradcheck[".Keys"] = $tableKeysradcheck;

$tdataradcheck[".listFields"] = array();
$tdataradcheck[".listFields"][] = "id";
$tdataradcheck[".listFields"][] = "username";
$tdataradcheck[".listFields"][] = "attribute";
$tdataradcheck[".listFields"][] = "op";
$tdataradcheck[".listFields"][] = "value";

$tdataradcheck[".hideMobileList"] = array();


$tdataradcheck[".viewFields"] = array();
$tdataradcheck[".viewFields"][] = "id";
$tdataradcheck[".viewFields"][] = "username";
$tdataradcheck[".viewFields"][] = "attribute";
$tdataradcheck[".viewFields"][] = "op";
$tdataradcheck[".viewFields"][] = "value";

$tdataradcheck[".addFields"] = array();
$tdataradcheck[".addFields"][] = "username";
$tdataradcheck[".addFields"][] = "attribute";
$tdataradcheck[".addFields"][] = "op";
$tdataradcheck[".addFields"][] = "value";

$tdataradcheck[".masterListFields"] = array();
$tdataradcheck[".masterListFields"][] = "id";
$tdataradcheck[".masterListFields"][] = "username";
$tdataradcheck[".masterListFields"][] = "attribute";
$tdataradcheck[".masterListFields"][] = "op";
$tdataradcheck[".masterListFields"][] = "value";

$tdataradcheck[".inlineAddFields"] = array();
$tdataradcheck[".inlineAddFields"][] = "username";
$tdataradcheck[".inlineAddFields"][] = "attribute";
$tdataradcheck[".inlineAddFields"][] = "op";
$tdataradcheck[".inlineAddFields"][] = "value";

$tdataradcheck[".editFields"] = array();
$tdataradcheck[".editFields"][] = "username";
$tdataradcheck[".editFields"][] = "attribute";
$tdataradcheck[".editFields"][] = "op";
$tdataradcheck[".editFields"][] = "value";

$tdataradcheck[".inlineEditFields"] = array();
$tdataradcheck[".inlineEditFields"][] = "username";
$tdataradcheck[".inlineEditFields"][] = "attribute";
$tdataradcheck[".inlineEditFields"][] = "op";
$tdataradcheck[".inlineEditFields"][] = "value";

$tdataradcheck[".exportFields"] = array();
$tdataradcheck[".exportFields"][] = "id";
$tdataradcheck[".exportFields"][] = "username";
$tdataradcheck[".exportFields"][] = "attribute";
$tdataradcheck[".exportFields"][] = "op";
$tdataradcheck[".exportFields"][] = "value";

$tdataradcheck[".importFields"] = array();
$tdataradcheck[".importFields"][] = "id";
$tdataradcheck[".importFields"][] = "username";
$tdataradcheck[".importFields"][] = "attribute";
$tdataradcheck[".importFields"][] = "op";
$tdataradcheck[".importFields"][] = "value";

$tdataradcheck[".printFields"] = array();
$tdataradcheck[".printFields"][] = "id";
$tdataradcheck[".printFields"][] = "username";
$tdataradcheck[".printFields"][] = "attribute";
$tdataradcheck[".printFields"][] = "op";
$tdataradcheck[".printFields"][] = "value";

//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "radcheck";
	$fdata["Label"] = GetFieldLabel("radcheck","id");
	$fdata["FieldType"] = 3;

	
		$fdata["AutoInc"] = true;

	
			
		$fdata["bListPage"] = true;

	
	
	
	
		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "id";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradcheck["id"] = $fdata;
//	username
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "username";
	$fdata["GoodName"] = "username";
	$fdata["ownerTable"] = "radcheck";
	$fdata["Label"] = GetFieldLabel("radcheck","username");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "username";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "username";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradcheck["username"] = $fdata;
//	attribute
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "attribute";
	$fdata["GoodName"] = "attribute";
	$fdata["ownerTable"] = "radcheck";
	$fdata["Label"] = GetFieldLabel("radcheck","attribute");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "attribute";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "attribute";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradcheck["attribute"] = $fdata;
//	op
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "op";
	$fdata["GoodName"] = "op";
	$fdata["ownerTable"] = "radcheck";
	$fdata["Label"] = GetFieldLabel("radcheck","op");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "op";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "op";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=2";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradcheck["op"] = $fdata;
//	value
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "value";
	$fdata["GoodName"] = "value";
	$fdata["ownerTable"] = "radcheck";
	$fdata["Label"] = GetFieldLabel("radcheck","value");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "value";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`value`";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=253";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradcheck["value"] = $fdata;


$tables_data["radcheck"]=&$tdataradcheck;
$field_labels["radcheck"] = &$fieldLabelsradcheck;
$fieldToolTips["radcheck"] = &$fieldToolTipsradcheck;
$page_titles["radcheck"] = &$pageTitlesradcheck;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["radcheck"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["radcheck"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_radcheck()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	username,  	attribute,  	op,  	`value`";
$proto0["m_strFrom"] = "FROM radcheck";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
$proto0["m_strTail"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "radcheck",
	"m_srcTableName" => "radcheck"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "radcheck";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "username",
	"m_strTable" => "radcheck",
	"m_srcTableName" => "radcheck"
));

$proto8["m_sql"] = "username";
$proto8["m_srcTableName"] = "radcheck";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "attribute",
	"m_strTable" => "radcheck",
	"m_srcTableName" => "radcheck"
));

$proto10["m_sql"] = "attribute";
$proto10["m_srcTableName"] = "radcheck";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "op",
	"m_strTable" => "radcheck",
	"m_srcTableName" => "radcheck"
));

$proto12["m_sql"] = "op";
$proto12["m_srcTableName"] = "radcheck";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "value",
	"m_strTable" => "radcheck",
	"m_srcTableName" => "radcheck"
));

$proto14["m_sql"] = "`value`";
$proto14["m_srcTableName"] = "radcheck";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto16=array();
$proto16["m_link"] = "SQLL_MAIN";
			$proto17=array();
$proto17["m_strName"] = "radcheck";
$proto17["m_srcTableName"] = "radcheck";
$proto17["m_columns"] = array();
$proto17["m_columns"][] = "id";
$proto17["m_columns"][] = "username";
$proto17["m_columns"][] = "attribute";
$proto17["m_columns"][] = "op";
$proto17["m_columns"][] = "value";
$obj = new SQLTable($proto17);

$proto16["m_table"] = $obj;
$proto16["m_sql"] = "radcheck";
$proto16["m_alias"] = "";
$proto16["m_srcTableName"] = "radcheck";
$proto18=array();
$proto18["m_sql"] = "";
$proto18["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto18["m_column"]=$obj;
$proto18["m_contained"] = array();
$proto18["m_strCase"] = "";
$proto18["m_havingmode"] = false;
$proto18["m_inBrackets"] = false;
$proto18["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto18);

$proto16["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto16);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="radcheck";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_radcheck = createSqlQuery_radcheck();


	
		;

					

$tdataradcheck[".sqlquery"] = $queryData_radcheck;

$tableEvents["radcheck"] = new eventsBase;
$tdataradcheck[".hasEvents"] = false;

?>