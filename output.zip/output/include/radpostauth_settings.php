<?php
require_once(getabspath("classes/cipherer.php"));




$tdataradpostauth = array();
	$tdataradpostauth[".truncateText"] = true;
	$tdataradpostauth[".NumberOfChars"] = 80;
	$tdataradpostauth[".ShortName"] = "radpostauth";
	$tdataradpostauth[".OwnerID"] = "";
	$tdataradpostauth[".OriginalTable"] = "radpostauth";

//	field labels
$fieldLabelsradpostauth = array();
$fieldToolTipsradpostauth = array();
$pageTitlesradpostauth = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsradpostauth["English"] = array();
	$fieldToolTipsradpostauth["English"] = array();
	$pageTitlesradpostauth["English"] = array();
	$fieldLabelsradpostauth["English"]["id"] = "Id";
	$fieldToolTipsradpostauth["English"]["id"] = "";
	$fieldLabelsradpostauth["English"]["username"] = "Username";
	$fieldToolTipsradpostauth["English"]["username"] = "";
	$fieldLabelsradpostauth["English"]["pass"] = "Pass";
	$fieldToolTipsradpostauth["English"]["pass"] = "";
	$fieldLabelsradpostauth["English"]["reply"] = "Reply";
	$fieldToolTipsradpostauth["English"]["reply"] = "";
	$fieldLabelsradpostauth["English"]["authdate"] = "Authdate";
	$fieldToolTipsradpostauth["English"]["authdate"] = "";
	if (count($fieldToolTipsradpostauth["English"]))
		$tdataradpostauth[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsradpostauth[""] = array();
	$fieldToolTipsradpostauth[""] = array();
	$pageTitlesradpostauth[""] = array();
	if (count($fieldToolTipsradpostauth[""]))
		$tdataradpostauth[".isUseToolTips"] = true;
}


	$tdataradpostauth[".NCSearch"] = true;



$tdataradpostauth[".shortTableName"] = "radpostauth";
$tdataradpostauth[".nSecOptions"] = 0;
$tdataradpostauth[".recsPerRowPrint"] = 1;
$tdataradpostauth[".mainTableOwnerID"] = "";
$tdataradpostauth[".moveNext"] = 1;
$tdataradpostauth[".entityType"] = 0;

$tdataradpostauth[".strOriginalTableName"] = "radpostauth";

	



$tdataradpostauth[".showAddInPopup"] = false;

$tdataradpostauth[".showEditInPopup"] = false;

$tdataradpostauth[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdataradpostauth[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataradpostauth[".fieldsForRegister"] = array();

$tdataradpostauth[".listAjax"] = false;

	$tdataradpostauth[".audit"] = false;

	$tdataradpostauth[".locking"] = false;

$tdataradpostauth[".edit"] = true;
$tdataradpostauth[".afterEditAction"] = 1;
$tdataradpostauth[".closePopupAfterEdit"] = 1;
$tdataradpostauth[".afterEditActionDetTable"] = "";

$tdataradpostauth[".add"] = true;
$tdataradpostauth[".afterAddAction"] = 1;
$tdataradpostauth[".closePopupAfterAdd"] = 1;
$tdataradpostauth[".afterAddActionDetTable"] = "";

$tdataradpostauth[".list"] = true;

$tdataradpostauth[".view"] = true;

$tdataradpostauth[".import"] = true;

$tdataradpostauth[".exportTo"] = true;

$tdataradpostauth[".printFriendly"] = true;

$tdataradpostauth[".delete"] = true;

$tdataradpostauth[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdataradpostauth[".searchSaving"] = false;
//

$tdataradpostauth[".showSearchPanel"] = true;
		$tdataradpostauth[".flexibleSearch"] = true;

$tdataradpostauth[".isUseAjaxSuggest"] = true;

$tdataradpostauth[".rowHighlite"] = true;



$tdataradpostauth[".addPageEvents"] = false;

// use timepicker for search panel
$tdataradpostauth[".isUseTimeForSearch"] = false;





$tdataradpostauth[".allSearchFields"] = array();
$tdataradpostauth[".filterFields"] = array();
$tdataradpostauth[".requiredSearchFields"] = array();

$tdataradpostauth[".allSearchFields"][] = "id";
	$tdataradpostauth[".allSearchFields"][] = "username";
	$tdataradpostauth[".allSearchFields"][] = "pass";
	$tdataradpostauth[".allSearchFields"][] = "reply";
	$tdataradpostauth[".allSearchFields"][] = "authdate";
	

$tdataradpostauth[".googleLikeFields"] = array();
$tdataradpostauth[".googleLikeFields"][] = "id";
$tdataradpostauth[".googleLikeFields"][] = "username";
$tdataradpostauth[".googleLikeFields"][] = "pass";
$tdataradpostauth[".googleLikeFields"][] = "reply";
$tdataradpostauth[".googleLikeFields"][] = "authdate";


$tdataradpostauth[".advSearchFields"] = array();
$tdataradpostauth[".advSearchFields"][] = "id";
$tdataradpostauth[".advSearchFields"][] = "username";
$tdataradpostauth[".advSearchFields"][] = "pass";
$tdataradpostauth[".advSearchFields"][] = "reply";
$tdataradpostauth[".advSearchFields"][] = "authdate";

$tdataradpostauth[".tableType"] = "list";

$tdataradpostauth[".printerPageOrientation"] = 0;
$tdataradpostauth[".nPrinterPageScale"] = 100;

$tdataradpostauth[".nPrinterSplitRecords"] = 40;

$tdataradpostauth[".nPrinterPDFSplitRecords"] = 40;



$tdataradpostauth[".geocodingEnabled"] = false;





$tdataradpostauth[".listGridLayout"] = 3;





// view page pdf

// print page pdf


$tdataradpostauth[".pageSize"] = 20;

$tdataradpostauth[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataradpostauth[".strOrderBy"] = $tstrOrderBy;

$tdataradpostauth[".orderindexes"] = array();

$tdataradpostauth[".sqlHead"] = "SELECT id,  	username,  	pass,  	reply,  	authdate";
$tdataradpostauth[".sqlFrom"] = "FROM radpostauth";
$tdataradpostauth[".sqlWhereExpr"] = "";
$tdataradpostauth[".sqlTail"] = "";











//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataradpostauth[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataradpostauth[".arrGroupsPerPage"] = $arrGPP;

$tdataradpostauth[".highlightSearchResults"] = true;

$tableKeysradpostauth = array();
$tableKeysradpostauth[] = "id";
$tdataradpostauth[".Keys"] = $tableKeysradpostauth;

$tdataradpostauth[".listFields"] = array();
$tdataradpostauth[".listFields"][] = "id";
$tdataradpostauth[".listFields"][] = "username";
$tdataradpostauth[".listFields"][] = "pass";
$tdataradpostauth[".listFields"][] = "reply";
$tdataradpostauth[".listFields"][] = "authdate";

$tdataradpostauth[".hideMobileList"] = array();


$tdataradpostauth[".viewFields"] = array();
$tdataradpostauth[".viewFields"][] = "id";
$tdataradpostauth[".viewFields"][] = "username";
$tdataradpostauth[".viewFields"][] = "pass";
$tdataradpostauth[".viewFields"][] = "reply";
$tdataradpostauth[".viewFields"][] = "authdate";

$tdataradpostauth[".addFields"] = array();
$tdataradpostauth[".addFields"][] = "username";
$tdataradpostauth[".addFields"][] = "pass";
$tdataradpostauth[".addFields"][] = "reply";
$tdataradpostauth[".addFields"][] = "authdate";

$tdataradpostauth[".masterListFields"] = array();
$tdataradpostauth[".masterListFields"][] = "id";
$tdataradpostauth[".masterListFields"][] = "username";
$tdataradpostauth[".masterListFields"][] = "pass";
$tdataradpostauth[".masterListFields"][] = "reply";
$tdataradpostauth[".masterListFields"][] = "authdate";

$tdataradpostauth[".inlineAddFields"] = array();
$tdataradpostauth[".inlineAddFields"][] = "username";
$tdataradpostauth[".inlineAddFields"][] = "pass";
$tdataradpostauth[".inlineAddFields"][] = "reply";
$tdataradpostauth[".inlineAddFields"][] = "authdate";

$tdataradpostauth[".editFields"] = array();
$tdataradpostauth[".editFields"][] = "username";
$tdataradpostauth[".editFields"][] = "pass";
$tdataradpostauth[".editFields"][] = "reply";
$tdataradpostauth[".editFields"][] = "authdate";

$tdataradpostauth[".inlineEditFields"] = array();
$tdataradpostauth[".inlineEditFields"][] = "username";
$tdataradpostauth[".inlineEditFields"][] = "pass";
$tdataradpostauth[".inlineEditFields"][] = "reply";
$tdataradpostauth[".inlineEditFields"][] = "authdate";

$tdataradpostauth[".exportFields"] = array();
$tdataradpostauth[".exportFields"][] = "id";
$tdataradpostauth[".exportFields"][] = "username";
$tdataradpostauth[".exportFields"][] = "pass";
$tdataradpostauth[".exportFields"][] = "reply";
$tdataradpostauth[".exportFields"][] = "authdate";

$tdataradpostauth[".importFields"] = array();
$tdataradpostauth[".importFields"][] = "id";
$tdataradpostauth[".importFields"][] = "username";
$tdataradpostauth[".importFields"][] = "pass";
$tdataradpostauth[".importFields"][] = "reply";
$tdataradpostauth[".importFields"][] = "authdate";

$tdataradpostauth[".printFields"] = array();
$tdataradpostauth[".printFields"][] = "id";
$tdataradpostauth[".printFields"][] = "username";
$tdataradpostauth[".printFields"][] = "pass";
$tdataradpostauth[".printFields"][] = "reply";
$tdataradpostauth[".printFields"][] = "authdate";

//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "radpostauth";
	$fdata["Label"] = GetFieldLabel("radpostauth","id");
	$fdata["FieldType"] = 3;

	
		$fdata["AutoInc"] = true;

	
			
		$fdata["bListPage"] = true;

	
	
	
	
		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "id";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradpostauth["id"] = $fdata;
//	username
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "username";
	$fdata["GoodName"] = "username";
	$fdata["ownerTable"] = "radpostauth";
	$fdata["Label"] = GetFieldLabel("radpostauth","username");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "username";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "username";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradpostauth["username"] = $fdata;
//	pass
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "pass";
	$fdata["GoodName"] = "pass";
	$fdata["ownerTable"] = "radpostauth";
	$fdata["Label"] = GetFieldLabel("radpostauth","pass");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "pass";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "pass";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradpostauth["pass"] = $fdata;
//	reply
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "reply";
	$fdata["GoodName"] = "reply";
	$fdata["ownerTable"] = "radpostauth";
	$fdata["Label"] = GetFieldLabel("radpostauth","reply");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "reply";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "reply";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=32";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradpostauth["reply"] = $fdata;
//	authdate
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "authdate";
	$fdata["GoodName"] = "authdate";
	$fdata["ownerTable"] = "radpostauth";
	$fdata["Label"] = GetFieldLabel("radpostauth","authdate");
	$fdata["FieldType"] = 135;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "authdate";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "authdate";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Short Date");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Date");

		$edata["ShowTime"] = true;

	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
		$edata["DateEditType"] = 13;
	$edata["InitialYearFactor"] = 100;
	$edata["LastYearFactor"] = 10;

	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings




	$tdataradpostauth["authdate"] = $fdata;


$tables_data["radpostauth"]=&$tdataradpostauth;
$field_labels["radpostauth"] = &$fieldLabelsradpostauth;
$fieldToolTips["radpostauth"] = &$fieldToolTipsradpostauth;
$page_titles["radpostauth"] = &$pageTitlesradpostauth;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["radpostauth"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["radpostauth"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_radpostauth()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	username,  	pass,  	reply,  	authdate";
$proto0["m_strFrom"] = "FROM radpostauth";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
$proto0["m_strTail"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "radpostauth",
	"m_srcTableName" => "radpostauth"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "radpostauth";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "username",
	"m_strTable" => "radpostauth",
	"m_srcTableName" => "radpostauth"
));

$proto8["m_sql"] = "username";
$proto8["m_srcTableName"] = "radpostauth";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "pass",
	"m_strTable" => "radpostauth",
	"m_srcTableName" => "radpostauth"
));

$proto10["m_sql"] = "pass";
$proto10["m_srcTableName"] = "radpostauth";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "reply",
	"m_strTable" => "radpostauth",
	"m_srcTableName" => "radpostauth"
));

$proto12["m_sql"] = "reply";
$proto12["m_srcTableName"] = "radpostauth";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "authdate",
	"m_strTable" => "radpostauth",
	"m_srcTableName" => "radpostauth"
));

$proto14["m_sql"] = "authdate";
$proto14["m_srcTableName"] = "radpostauth";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto16=array();
$proto16["m_link"] = "SQLL_MAIN";
			$proto17=array();
$proto17["m_strName"] = "radpostauth";
$proto17["m_srcTableName"] = "radpostauth";
$proto17["m_columns"] = array();
$proto17["m_columns"][] = "id";
$proto17["m_columns"][] = "username";
$proto17["m_columns"][] = "pass";
$proto17["m_columns"][] = "reply";
$proto17["m_columns"][] = "authdate";
$obj = new SQLTable($proto17);

$proto16["m_table"] = $obj;
$proto16["m_sql"] = "radpostauth";
$proto16["m_alias"] = "";
$proto16["m_srcTableName"] = "radpostauth";
$proto18=array();
$proto18["m_sql"] = "";
$proto18["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto18["m_column"]=$obj;
$proto18["m_contained"] = array();
$proto18["m_strCase"] = "";
$proto18["m_havingmode"] = false;
$proto18["m_inBrackets"] = false;
$proto18["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto18);

$proto16["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto16);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="radpostauth";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_radpostauth = createSqlQuery_radpostauth();


	
		;

					

$tdataradpostauth[".sqlquery"] = $queryData_radpostauth;

$tableEvents["radpostauth"] = new eventsBase;
$tdataradpostauth[".hasEvents"] = false;

?>