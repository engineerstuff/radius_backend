<?php
$dalTableadmins = array();
$dalTableadmins["id"] = array("type"=>3,"varname"=>"id");
$dalTableadmins["username"] = array("type"=>200,"varname"=>"username");
$dalTableadmins["firstname"] = array("type"=>200,"varname"=>"firstname");
$dalTableadmins["lastname"] = array("type"=>200,"varname"=>"lastname");
$dalTableadmins["password"] = array("type"=>200,"varname"=>"password");
	$dalTableadmins["id"]["key"]=true;

$dal_info["radius_at_localhost__admins"] = &$dalTableadmins;
?>