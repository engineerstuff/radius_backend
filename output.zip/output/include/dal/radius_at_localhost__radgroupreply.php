<?php
$dalTableradgroupreply = array();
$dalTableradgroupreply["id"] = array("type"=>3,"varname"=>"id");
$dalTableradgroupreply["groupname"] = array("type"=>200,"varname"=>"groupname");
$dalTableradgroupreply["attribute"] = array("type"=>200,"varname"=>"attribute");
$dalTableradgroupreply["op"] = array("type"=>200,"varname"=>"op");
$dalTableradgroupreply["value"] = array("type"=>200,"varname"=>"fldvalue");
	$dalTableradgroupreply["id"]["key"]=true;

$dal_info["radius_at_localhost__radgroupreply"] = &$dalTableradgroupreply;
?>