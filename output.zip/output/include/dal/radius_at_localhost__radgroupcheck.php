<?php
$dalTableradgroupcheck = array();
$dalTableradgroupcheck["id"] = array("type"=>3,"varname"=>"id");
$dalTableradgroupcheck["groupname"] = array("type"=>200,"varname"=>"groupname");
$dalTableradgroupcheck["attribute"] = array("type"=>200,"varname"=>"attribute");
$dalTableradgroupcheck["op"] = array("type"=>200,"varname"=>"op");
$dalTableradgroupcheck["value"] = array("type"=>200,"varname"=>"fldvalue");
	$dalTableradgroupcheck["id"]["key"]=true;

$dal_info["radius_at_localhost__radgroupcheck"] = &$dalTableradgroupcheck;
?>