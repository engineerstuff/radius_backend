<?php
$dalTableradusergroup = array();
$dalTableradusergroup["username"] = array("type"=>200,"varname"=>"username");
$dalTableradusergroup["groupname"] = array("type"=>200,"varname"=>"groupname");
$dalTableradusergroup["priority"] = array("type"=>3,"varname"=>"priority");

$dal_info["radius_at_localhost__radusergroup"] = &$dalTableradusergroup;
?>