<?php
$dalTableradacct = array();
$dalTableradacct["radacctid"] = array("type"=>20,"varname"=>"radacctid");
$dalTableradacct["acctsessionid"] = array("type"=>200,"varname"=>"acctsessionid");
$dalTableradacct["acctuniqueid"] = array("type"=>200,"varname"=>"acctuniqueid");
$dalTableradacct["username"] = array("type"=>200,"varname"=>"username");
$dalTableradacct["groupname"] = array("type"=>200,"varname"=>"groupname");
$dalTableradacct["realm"] = array("type"=>200,"varname"=>"realm");
$dalTableradacct["nasipaddress"] = array("type"=>200,"varname"=>"nasipaddress");
$dalTableradacct["nasportid"] = array("type"=>200,"varname"=>"nasportid");
$dalTableradacct["nasporttype"] = array("type"=>200,"varname"=>"nasporttype");
$dalTableradacct["acctstarttime"] = array("type"=>135,"varname"=>"acctstarttime");
$dalTableradacct["acctupdatetime"] = array("type"=>135,"varname"=>"acctupdatetime");
$dalTableradacct["acctstoptime"] = array("type"=>135,"varname"=>"acctstoptime");
$dalTableradacct["acctinterval"] = array("type"=>3,"varname"=>"acctinterval");
$dalTableradacct["acctsessiontime"] = array("type"=>3,"varname"=>"acctsessiontime");
$dalTableradacct["acctauthentic"] = array("type"=>200,"varname"=>"acctauthentic");
$dalTableradacct["connectinfo_start"] = array("type"=>200,"varname"=>"connectinfo_start");
$dalTableradacct["connectinfo_stop"] = array("type"=>200,"varname"=>"connectinfo_stop");
$dalTableradacct["acctinputoctets"] = array("type"=>20,"varname"=>"acctinputoctets");
$dalTableradacct["acctoutputoctets"] = array("type"=>20,"varname"=>"acctoutputoctets");
$dalTableradacct["calledstationid"] = array("type"=>200,"varname"=>"calledstationid");
$dalTableradacct["callingstationid"] = array("type"=>200,"varname"=>"callingstationid");
$dalTableradacct["acctterminatecause"] = array("type"=>200,"varname"=>"acctterminatecause");
$dalTableradacct["servicetype"] = array("type"=>200,"varname"=>"servicetype");
$dalTableradacct["framedprotocol"] = array("type"=>200,"varname"=>"framedprotocol");
$dalTableradacct["framedipaddress"] = array("type"=>200,"varname"=>"framedipaddress");
	$dalTableradacct["radacctid"]["key"]=true;

$dal_info["radius_at_localhost__radacct"] = &$dalTableradacct;
?>