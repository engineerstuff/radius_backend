<?php
$dalTableradpostauth = array();
$dalTableradpostauth["id"] = array("type"=>3,"varname"=>"id");
$dalTableradpostauth["username"] = array("type"=>200,"varname"=>"username");
$dalTableradpostauth["pass"] = array("type"=>200,"varname"=>"pass");
$dalTableradpostauth["reply"] = array("type"=>200,"varname"=>"reply");
$dalTableradpostauth["authdate"] = array("type"=>135,"varname"=>"authdate");
	$dalTableradpostauth["id"]["key"]=true;

$dal_info["radius_at_localhost__radpostauth"] = &$dalTableradpostauth;
?>