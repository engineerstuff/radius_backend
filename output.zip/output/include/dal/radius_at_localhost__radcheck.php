<?php
$dalTableradcheck = array();
$dalTableradcheck["id"] = array("type"=>3,"varname"=>"id");
$dalTableradcheck["username"] = array("type"=>200,"varname"=>"username");
$dalTableradcheck["attribute"] = array("type"=>200,"varname"=>"attribute");
$dalTableradcheck["op"] = array("type"=>200,"varname"=>"op");
$dalTableradcheck["value"] = array("type"=>200,"varname"=>"fldvalue");
	$dalTableradcheck["id"]["key"]=true;

$dal_info["radius_at_localhost__radcheck"] = &$dalTableradcheck;
?>