<?php
$dalTableradreply = array();
$dalTableradreply["id"] = array("type"=>3,"varname"=>"id");
$dalTableradreply["username"] = array("type"=>200,"varname"=>"username");
$dalTableradreply["attribute"] = array("type"=>200,"varname"=>"attribute");
$dalTableradreply["op"] = array("type"=>200,"varname"=>"op");
$dalTableradreply["value"] = array("type"=>200,"varname"=>"fldvalue");
	$dalTableradreply["id"]["key"]=true;

$dal_info["radius_at_localhost__radreply"] = &$dalTableradreply;
?>