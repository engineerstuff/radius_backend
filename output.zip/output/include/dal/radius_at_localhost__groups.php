<?php
$dalTablegroups = array();
$dalTablegroups["id"] = array("type"=>3,"varname"=>"id");
$dalTablegroups["name"] = array("type"=>200,"varname"=>"name");
$dalTablegroups["description"] = array("type"=>200,"varname"=>"description");
	$dalTablegroups["id"]["key"]=true;

$dal_info["radius_at_localhost__groups"] = &$dalTablegroups;
?>