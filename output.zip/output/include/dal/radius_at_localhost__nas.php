<?php
$dalTablenas = array();
$dalTablenas["id"] = array("type"=>3,"varname"=>"id");
$dalTablenas["nasname"] = array("type"=>200,"varname"=>"nasname");
$dalTablenas["shortname"] = array("type"=>200,"varname"=>"shortname");
$dalTablenas["type"] = array("type"=>200,"varname"=>"type");
$dalTablenas["ports"] = array("type"=>3,"varname"=>"ports");
$dalTablenas["secret"] = array("type"=>200,"varname"=>"secret");
$dalTablenas["server"] = array("type"=>200,"varname"=>"server");
$dalTablenas["community"] = array("type"=>200,"varname"=>"community");
$dalTablenas["description"] = array("type"=>200,"varname"=>"description");
	$dalTablenas["id"]["key"]=true;

$dal_info["radius_at_localhost__nas"] = &$dalTablenas;
?>