<?php
$dalTableusers = array();
$dalTableusers["id"] = array("type"=>3,"varname"=>"id");
$dalTableusers["username"] = array("type"=>200,"varname"=>"username");
$dalTableusers["firstname"] = array("type"=>200,"varname"=>"firstname");
$dalTableusers["lastname"] = array("type"=>200,"varname"=>"lastname");
	$dalTableusers["id"]["key"]=true;

$dal_info["radius_at_localhost__users"] = &$dalTableusers;
?>