<?php
require_once(getabspath("classes/cipherer.php"));




$tdataradacct = array();
	$tdataradacct[".truncateText"] = true;
	$tdataradacct[".NumberOfChars"] = 80;
	$tdataradacct[".ShortName"] = "radacct";
	$tdataradacct[".OwnerID"] = "";
	$tdataradacct[".OriginalTable"] = "radacct";

//	field labels
$fieldLabelsradacct = array();
$fieldToolTipsradacct = array();
$pageTitlesradacct = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsradacct["English"] = array();
	$fieldToolTipsradacct["English"] = array();
	$pageTitlesradacct["English"] = array();
	$fieldLabelsradacct["English"]["radacctid"] = "Radacctid";
	$fieldToolTipsradacct["English"]["radacctid"] = "";
	$fieldLabelsradacct["English"]["acctsessionid"] = "Acctsessionid";
	$fieldToolTipsradacct["English"]["acctsessionid"] = "";
	$fieldLabelsradacct["English"]["acctuniqueid"] = "Acctuniqueid";
	$fieldToolTipsradacct["English"]["acctuniqueid"] = "";
	$fieldLabelsradacct["English"]["username"] = "Username";
	$fieldToolTipsradacct["English"]["username"] = "";
	$fieldLabelsradacct["English"]["groupname"] = "Groupname";
	$fieldToolTipsradacct["English"]["groupname"] = "";
	$fieldLabelsradacct["English"]["realm"] = "Realm";
	$fieldToolTipsradacct["English"]["realm"] = "";
	$fieldLabelsradacct["English"]["nasipaddress"] = "Nasipaddress";
	$fieldToolTipsradacct["English"]["nasipaddress"] = "";
	$fieldLabelsradacct["English"]["nasportid"] = "Nasportid";
	$fieldToolTipsradacct["English"]["nasportid"] = "";
	$fieldLabelsradacct["English"]["nasporttype"] = "Nasporttype";
	$fieldToolTipsradacct["English"]["nasporttype"] = "";
	$fieldLabelsradacct["English"]["acctstarttime"] = "Acctstarttime";
	$fieldToolTipsradacct["English"]["acctstarttime"] = "";
	$fieldLabelsradacct["English"]["acctupdatetime"] = "Acctupdatetime";
	$fieldToolTipsradacct["English"]["acctupdatetime"] = "";
	$fieldLabelsradacct["English"]["acctstoptime"] = "Acctstoptime";
	$fieldToolTipsradacct["English"]["acctstoptime"] = "";
	$fieldLabelsradacct["English"]["acctinterval"] = "Acctinterval";
	$fieldToolTipsradacct["English"]["acctinterval"] = "";
	$fieldLabelsradacct["English"]["acctsessiontime"] = "Acctsessiontime";
	$fieldToolTipsradacct["English"]["acctsessiontime"] = "";
	$fieldLabelsradacct["English"]["acctauthentic"] = "Acctauthentic";
	$fieldToolTipsradacct["English"]["acctauthentic"] = "";
	$fieldLabelsradacct["English"]["connectinfo_start"] = "Connectinfo Start";
	$fieldToolTipsradacct["English"]["connectinfo_start"] = "";
	$fieldLabelsradacct["English"]["connectinfo_stop"] = "Connectinfo Stop";
	$fieldToolTipsradacct["English"]["connectinfo_stop"] = "";
	$fieldLabelsradacct["English"]["acctinputoctets"] = "Acctinputoctets";
	$fieldToolTipsradacct["English"]["acctinputoctets"] = "";
	$fieldLabelsradacct["English"]["acctoutputoctets"] = "Acctoutputoctets";
	$fieldToolTipsradacct["English"]["acctoutputoctets"] = "";
	$fieldLabelsradacct["English"]["calledstationid"] = "Calledstationid";
	$fieldToolTipsradacct["English"]["calledstationid"] = "";
	$fieldLabelsradacct["English"]["callingstationid"] = "Callingstationid";
	$fieldToolTipsradacct["English"]["callingstationid"] = "";
	$fieldLabelsradacct["English"]["acctterminatecause"] = "Acctterminatecause";
	$fieldToolTipsradacct["English"]["acctterminatecause"] = "";
	$fieldLabelsradacct["English"]["servicetype"] = "Servicetype";
	$fieldToolTipsradacct["English"]["servicetype"] = "";
	$fieldLabelsradacct["English"]["framedprotocol"] = "Framedprotocol";
	$fieldToolTipsradacct["English"]["framedprotocol"] = "";
	$fieldLabelsradacct["English"]["framedipaddress"] = "Framedipaddress";
	$fieldToolTipsradacct["English"]["framedipaddress"] = "";
	if (count($fieldToolTipsradacct["English"]))
		$tdataradacct[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsradacct[""] = array();
	$fieldToolTipsradacct[""] = array();
	$pageTitlesradacct[""] = array();
	if (count($fieldToolTipsradacct[""]))
		$tdataradacct[".isUseToolTips"] = true;
}


	$tdataradacct[".NCSearch"] = true;



$tdataradacct[".shortTableName"] = "radacct";
$tdataradacct[".nSecOptions"] = 0;
$tdataradacct[".recsPerRowPrint"] = 1;
$tdataradacct[".mainTableOwnerID"] = "";
$tdataradacct[".moveNext"] = 1;
$tdataradacct[".entityType"] = 0;

$tdataradacct[".strOriginalTableName"] = "radacct";

	



$tdataradacct[".showAddInPopup"] = false;

$tdataradacct[".showEditInPopup"] = false;

$tdataradacct[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdataradacct[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataradacct[".fieldsForRegister"] = array();

$tdataradacct[".listAjax"] = false;

	$tdataradacct[".audit"] = false;

	$tdataradacct[".locking"] = false;

$tdataradacct[".edit"] = true;
$tdataradacct[".afterEditAction"] = 1;
$tdataradacct[".closePopupAfterEdit"] = 1;
$tdataradacct[".afterEditActionDetTable"] = "";

$tdataradacct[".add"] = true;
$tdataradacct[".afterAddAction"] = 1;
$tdataradacct[".closePopupAfterAdd"] = 1;
$tdataradacct[".afterAddActionDetTable"] = "";

$tdataradacct[".list"] = true;

$tdataradacct[".view"] = true;

$tdataradacct[".import"] = true;

$tdataradacct[".exportTo"] = true;

$tdataradacct[".printFriendly"] = true;

$tdataradacct[".delete"] = true;

$tdataradacct[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdataradacct[".searchSaving"] = false;
//

$tdataradacct[".showSearchPanel"] = true;
		$tdataradacct[".flexibleSearch"] = true;

$tdataradacct[".isUseAjaxSuggest"] = true;

$tdataradacct[".rowHighlite"] = true;



$tdataradacct[".addPageEvents"] = false;

// use timepicker for search panel
$tdataradacct[".isUseTimeForSearch"] = false;





$tdataradacct[".allSearchFields"] = array();
$tdataradacct[".filterFields"] = array();
$tdataradacct[".requiredSearchFields"] = array();

$tdataradacct[".allSearchFields"][] = "radacctid";
	$tdataradacct[".allSearchFields"][] = "acctsessionid";
	$tdataradacct[".allSearchFields"][] = "acctuniqueid";
	$tdataradacct[".allSearchFields"][] = "username";
	$tdataradacct[".allSearchFields"][] = "groupname";
	$tdataradacct[".allSearchFields"][] = "realm";
	$tdataradacct[".allSearchFields"][] = "nasipaddress";
	$tdataradacct[".allSearchFields"][] = "nasportid";
	$tdataradacct[".allSearchFields"][] = "nasporttype";
	$tdataradacct[".allSearchFields"][] = "acctstarttime";
	$tdataradacct[".allSearchFields"][] = "acctupdatetime";
	$tdataradacct[".allSearchFields"][] = "acctstoptime";
	$tdataradacct[".allSearchFields"][] = "acctinterval";
	$tdataradacct[".allSearchFields"][] = "acctsessiontime";
	$tdataradacct[".allSearchFields"][] = "acctauthentic";
	$tdataradacct[".allSearchFields"][] = "connectinfo_start";
	$tdataradacct[".allSearchFields"][] = "connectinfo_stop";
	$tdataradacct[".allSearchFields"][] = "acctinputoctets";
	$tdataradacct[".allSearchFields"][] = "acctoutputoctets";
	$tdataradacct[".allSearchFields"][] = "calledstationid";
	$tdataradacct[".allSearchFields"][] = "callingstationid";
	$tdataradacct[".allSearchFields"][] = "acctterminatecause";
	$tdataradacct[".allSearchFields"][] = "servicetype";
	$tdataradacct[".allSearchFields"][] = "framedprotocol";
	$tdataradacct[".allSearchFields"][] = "framedipaddress";
	

$tdataradacct[".googleLikeFields"] = array();
$tdataradacct[".googleLikeFields"][] = "radacctid";
$tdataradacct[".googleLikeFields"][] = "acctsessionid";
$tdataradacct[".googleLikeFields"][] = "acctuniqueid";
$tdataradacct[".googleLikeFields"][] = "username";
$tdataradacct[".googleLikeFields"][] = "groupname";
$tdataradacct[".googleLikeFields"][] = "realm";
$tdataradacct[".googleLikeFields"][] = "nasipaddress";
$tdataradacct[".googleLikeFields"][] = "nasportid";
$tdataradacct[".googleLikeFields"][] = "nasporttype";
$tdataradacct[".googleLikeFields"][] = "acctstarttime";
$tdataradacct[".googleLikeFields"][] = "acctupdatetime";
$tdataradacct[".googleLikeFields"][] = "acctstoptime";
$tdataradacct[".googleLikeFields"][] = "acctinterval";
$tdataradacct[".googleLikeFields"][] = "acctsessiontime";
$tdataradacct[".googleLikeFields"][] = "acctauthentic";
$tdataradacct[".googleLikeFields"][] = "connectinfo_start";
$tdataradacct[".googleLikeFields"][] = "connectinfo_stop";
$tdataradacct[".googleLikeFields"][] = "acctinputoctets";
$tdataradacct[".googleLikeFields"][] = "acctoutputoctets";
$tdataradacct[".googleLikeFields"][] = "calledstationid";
$tdataradacct[".googleLikeFields"][] = "callingstationid";
$tdataradacct[".googleLikeFields"][] = "acctterminatecause";
$tdataradacct[".googleLikeFields"][] = "servicetype";
$tdataradacct[".googleLikeFields"][] = "framedprotocol";
$tdataradacct[".googleLikeFields"][] = "framedipaddress";


$tdataradacct[".advSearchFields"] = array();
$tdataradacct[".advSearchFields"][] = "radacctid";
$tdataradacct[".advSearchFields"][] = "acctsessionid";
$tdataradacct[".advSearchFields"][] = "acctuniqueid";
$tdataradacct[".advSearchFields"][] = "username";
$tdataradacct[".advSearchFields"][] = "groupname";
$tdataradacct[".advSearchFields"][] = "realm";
$tdataradacct[".advSearchFields"][] = "nasipaddress";
$tdataradacct[".advSearchFields"][] = "nasportid";
$tdataradacct[".advSearchFields"][] = "nasporttype";
$tdataradacct[".advSearchFields"][] = "acctstarttime";
$tdataradacct[".advSearchFields"][] = "acctupdatetime";
$tdataradacct[".advSearchFields"][] = "acctstoptime";
$tdataradacct[".advSearchFields"][] = "acctinterval";
$tdataradacct[".advSearchFields"][] = "acctsessiontime";
$tdataradacct[".advSearchFields"][] = "acctauthentic";
$tdataradacct[".advSearchFields"][] = "connectinfo_start";
$tdataradacct[".advSearchFields"][] = "connectinfo_stop";
$tdataradacct[".advSearchFields"][] = "acctinputoctets";
$tdataradacct[".advSearchFields"][] = "acctoutputoctets";
$tdataradacct[".advSearchFields"][] = "calledstationid";
$tdataradacct[".advSearchFields"][] = "callingstationid";
$tdataradacct[".advSearchFields"][] = "acctterminatecause";
$tdataradacct[".advSearchFields"][] = "servicetype";
$tdataradacct[".advSearchFields"][] = "framedprotocol";
$tdataradacct[".advSearchFields"][] = "framedipaddress";

$tdataradacct[".tableType"] = "list";

$tdataradacct[".printerPageOrientation"] = 0;
$tdataradacct[".nPrinterPageScale"] = 100;

$tdataradacct[".nPrinterSplitRecords"] = 40;

$tdataradacct[".nPrinterPDFSplitRecords"] = 40;



$tdataradacct[".geocodingEnabled"] = false;





$tdataradacct[".listGridLayout"] = 3;





// view page pdf

// print page pdf


$tdataradacct[".pageSize"] = 20;

$tdataradacct[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataradacct[".strOrderBy"] = $tstrOrderBy;

$tdataradacct[".orderindexes"] = array();

$tdataradacct[".sqlHead"] = "SELECT radacctid,  	acctsessionid,  	acctuniqueid,  	username,  	groupname,  	realm,  	nasipaddress,  	nasportid,  	nasporttype,  	acctstarttime,  	acctupdatetime,  	acctstoptime,  	acctinterval,  	acctsessiontime,  	acctauthentic,  	connectinfo_start,  	connectinfo_stop,  	acctinputoctets,  	acctoutputoctets,  	calledstationid,  	callingstationid,  	acctterminatecause,  	servicetype,  	framedprotocol,  	framedipaddress";
$tdataradacct[".sqlFrom"] = "FROM radacct";
$tdataradacct[".sqlWhereExpr"] = "";
$tdataradacct[".sqlTail"] = "";











//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataradacct[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataradacct[".arrGroupsPerPage"] = $arrGPP;

$tdataradacct[".highlightSearchResults"] = true;

$tableKeysradacct = array();
$tableKeysradacct[] = "radacctid";
$tdataradacct[".Keys"] = $tableKeysradacct;

$tdataradacct[".listFields"] = array();
$tdataradacct[".listFields"][] = "radacctid";
$tdataradacct[".listFields"][] = "acctsessionid";
$tdataradacct[".listFields"][] = "acctuniqueid";
$tdataradacct[".listFields"][] = "username";
$tdataradacct[".listFields"][] = "groupname";
$tdataradacct[".listFields"][] = "realm";
$tdataradacct[".listFields"][] = "nasipaddress";
$tdataradacct[".listFields"][] = "nasportid";
$tdataradacct[".listFields"][] = "nasporttype";
$tdataradacct[".listFields"][] = "acctstarttime";
$tdataradacct[".listFields"][] = "acctupdatetime";
$tdataradacct[".listFields"][] = "acctstoptime";
$tdataradacct[".listFields"][] = "acctinterval";
$tdataradacct[".listFields"][] = "acctsessiontime";
$tdataradacct[".listFields"][] = "acctauthentic";
$tdataradacct[".listFields"][] = "connectinfo_start";
$tdataradacct[".listFields"][] = "connectinfo_stop";
$tdataradacct[".listFields"][] = "acctinputoctets";
$tdataradacct[".listFields"][] = "acctoutputoctets";
$tdataradacct[".listFields"][] = "calledstationid";
$tdataradacct[".listFields"][] = "callingstationid";
$tdataradacct[".listFields"][] = "acctterminatecause";
$tdataradacct[".listFields"][] = "servicetype";
$tdataradacct[".listFields"][] = "framedprotocol";
$tdataradacct[".listFields"][] = "framedipaddress";

$tdataradacct[".hideMobileList"] = array();


$tdataradacct[".viewFields"] = array();
$tdataradacct[".viewFields"][] = "radacctid";
$tdataradacct[".viewFields"][] = "acctsessionid";
$tdataradacct[".viewFields"][] = "acctuniqueid";
$tdataradacct[".viewFields"][] = "username";
$tdataradacct[".viewFields"][] = "groupname";
$tdataradacct[".viewFields"][] = "realm";
$tdataradacct[".viewFields"][] = "nasipaddress";
$tdataradacct[".viewFields"][] = "nasportid";
$tdataradacct[".viewFields"][] = "nasporttype";
$tdataradacct[".viewFields"][] = "acctstarttime";
$tdataradacct[".viewFields"][] = "acctupdatetime";
$tdataradacct[".viewFields"][] = "acctstoptime";
$tdataradacct[".viewFields"][] = "acctinterval";
$tdataradacct[".viewFields"][] = "acctsessiontime";
$tdataradacct[".viewFields"][] = "acctauthentic";
$tdataradacct[".viewFields"][] = "connectinfo_start";
$tdataradacct[".viewFields"][] = "connectinfo_stop";
$tdataradacct[".viewFields"][] = "acctinputoctets";
$tdataradacct[".viewFields"][] = "acctoutputoctets";
$tdataradacct[".viewFields"][] = "calledstationid";
$tdataradacct[".viewFields"][] = "callingstationid";
$tdataradacct[".viewFields"][] = "acctterminatecause";
$tdataradacct[".viewFields"][] = "servicetype";
$tdataradacct[".viewFields"][] = "framedprotocol";
$tdataradacct[".viewFields"][] = "framedipaddress";

$tdataradacct[".addFields"] = array();
$tdataradacct[".addFields"][] = "acctsessionid";
$tdataradacct[".addFields"][] = "acctuniqueid";
$tdataradacct[".addFields"][] = "username";
$tdataradacct[".addFields"][] = "groupname";
$tdataradacct[".addFields"][] = "realm";
$tdataradacct[".addFields"][] = "nasipaddress";
$tdataradacct[".addFields"][] = "nasportid";
$tdataradacct[".addFields"][] = "nasporttype";
$tdataradacct[".addFields"][] = "acctstarttime";
$tdataradacct[".addFields"][] = "acctupdatetime";
$tdataradacct[".addFields"][] = "acctstoptime";
$tdataradacct[".addFields"][] = "acctinterval";
$tdataradacct[".addFields"][] = "acctsessiontime";
$tdataradacct[".addFields"][] = "acctauthentic";
$tdataradacct[".addFields"][] = "connectinfo_start";
$tdataradacct[".addFields"][] = "connectinfo_stop";
$tdataradacct[".addFields"][] = "acctinputoctets";
$tdataradacct[".addFields"][] = "acctoutputoctets";
$tdataradacct[".addFields"][] = "calledstationid";
$tdataradacct[".addFields"][] = "callingstationid";
$tdataradacct[".addFields"][] = "acctterminatecause";
$tdataradacct[".addFields"][] = "servicetype";
$tdataradacct[".addFields"][] = "framedprotocol";
$tdataradacct[".addFields"][] = "framedipaddress";

$tdataradacct[".masterListFields"] = array();
$tdataradacct[".masterListFields"][] = "radacctid";
$tdataradacct[".masterListFields"][] = "acctsessionid";
$tdataradacct[".masterListFields"][] = "acctuniqueid";
$tdataradacct[".masterListFields"][] = "username";
$tdataradacct[".masterListFields"][] = "groupname";
$tdataradacct[".masterListFields"][] = "realm";
$tdataradacct[".masterListFields"][] = "nasipaddress";
$tdataradacct[".masterListFields"][] = "nasportid";
$tdataradacct[".masterListFields"][] = "nasporttype";
$tdataradacct[".masterListFields"][] = "acctstarttime";
$tdataradacct[".masterListFields"][] = "acctupdatetime";
$tdataradacct[".masterListFields"][] = "acctstoptime";
$tdataradacct[".masterListFields"][] = "acctinterval";
$tdataradacct[".masterListFields"][] = "acctsessiontime";
$tdataradacct[".masterListFields"][] = "acctauthentic";
$tdataradacct[".masterListFields"][] = "connectinfo_start";
$tdataradacct[".masterListFields"][] = "connectinfo_stop";
$tdataradacct[".masterListFields"][] = "acctinputoctets";
$tdataradacct[".masterListFields"][] = "acctoutputoctets";
$tdataradacct[".masterListFields"][] = "calledstationid";
$tdataradacct[".masterListFields"][] = "callingstationid";
$tdataradacct[".masterListFields"][] = "acctterminatecause";
$tdataradacct[".masterListFields"][] = "servicetype";
$tdataradacct[".masterListFields"][] = "framedprotocol";
$tdataradacct[".masterListFields"][] = "framedipaddress";

$tdataradacct[".inlineAddFields"] = array();
$tdataradacct[".inlineAddFields"][] = "acctsessionid";
$tdataradacct[".inlineAddFields"][] = "acctuniqueid";
$tdataradacct[".inlineAddFields"][] = "username";
$tdataradacct[".inlineAddFields"][] = "groupname";
$tdataradacct[".inlineAddFields"][] = "realm";
$tdataradacct[".inlineAddFields"][] = "nasipaddress";
$tdataradacct[".inlineAddFields"][] = "nasportid";
$tdataradacct[".inlineAddFields"][] = "nasporttype";
$tdataradacct[".inlineAddFields"][] = "acctstarttime";
$tdataradacct[".inlineAddFields"][] = "acctupdatetime";
$tdataradacct[".inlineAddFields"][] = "acctstoptime";
$tdataradacct[".inlineAddFields"][] = "acctinterval";
$tdataradacct[".inlineAddFields"][] = "acctsessiontime";
$tdataradacct[".inlineAddFields"][] = "acctauthentic";
$tdataradacct[".inlineAddFields"][] = "connectinfo_start";
$tdataradacct[".inlineAddFields"][] = "connectinfo_stop";
$tdataradacct[".inlineAddFields"][] = "acctinputoctets";
$tdataradacct[".inlineAddFields"][] = "acctoutputoctets";
$tdataradacct[".inlineAddFields"][] = "calledstationid";
$tdataradacct[".inlineAddFields"][] = "callingstationid";
$tdataradacct[".inlineAddFields"][] = "acctterminatecause";
$tdataradacct[".inlineAddFields"][] = "servicetype";
$tdataradacct[".inlineAddFields"][] = "framedprotocol";
$tdataradacct[".inlineAddFields"][] = "framedipaddress";

$tdataradacct[".editFields"] = array();
$tdataradacct[".editFields"][] = "acctsessionid";
$tdataradacct[".editFields"][] = "acctuniqueid";
$tdataradacct[".editFields"][] = "username";
$tdataradacct[".editFields"][] = "groupname";
$tdataradacct[".editFields"][] = "realm";
$tdataradacct[".editFields"][] = "nasipaddress";
$tdataradacct[".editFields"][] = "nasportid";
$tdataradacct[".editFields"][] = "nasporttype";
$tdataradacct[".editFields"][] = "acctstarttime";
$tdataradacct[".editFields"][] = "acctupdatetime";
$tdataradacct[".editFields"][] = "acctstoptime";
$tdataradacct[".editFields"][] = "acctinterval";
$tdataradacct[".editFields"][] = "acctsessiontime";
$tdataradacct[".editFields"][] = "acctauthentic";
$tdataradacct[".editFields"][] = "connectinfo_start";
$tdataradacct[".editFields"][] = "connectinfo_stop";
$tdataradacct[".editFields"][] = "acctinputoctets";
$tdataradacct[".editFields"][] = "acctoutputoctets";
$tdataradacct[".editFields"][] = "calledstationid";
$tdataradacct[".editFields"][] = "callingstationid";
$tdataradacct[".editFields"][] = "acctterminatecause";
$tdataradacct[".editFields"][] = "servicetype";
$tdataradacct[".editFields"][] = "framedprotocol";
$tdataradacct[".editFields"][] = "framedipaddress";

$tdataradacct[".inlineEditFields"] = array();
$tdataradacct[".inlineEditFields"][] = "acctsessionid";
$tdataradacct[".inlineEditFields"][] = "acctuniqueid";
$tdataradacct[".inlineEditFields"][] = "username";
$tdataradacct[".inlineEditFields"][] = "groupname";
$tdataradacct[".inlineEditFields"][] = "realm";
$tdataradacct[".inlineEditFields"][] = "nasipaddress";
$tdataradacct[".inlineEditFields"][] = "nasportid";
$tdataradacct[".inlineEditFields"][] = "nasporttype";
$tdataradacct[".inlineEditFields"][] = "acctstarttime";
$tdataradacct[".inlineEditFields"][] = "acctupdatetime";
$tdataradacct[".inlineEditFields"][] = "acctstoptime";
$tdataradacct[".inlineEditFields"][] = "acctinterval";
$tdataradacct[".inlineEditFields"][] = "acctsessiontime";
$tdataradacct[".inlineEditFields"][] = "acctauthentic";
$tdataradacct[".inlineEditFields"][] = "connectinfo_start";
$tdataradacct[".inlineEditFields"][] = "connectinfo_stop";
$tdataradacct[".inlineEditFields"][] = "acctinputoctets";
$tdataradacct[".inlineEditFields"][] = "acctoutputoctets";
$tdataradacct[".inlineEditFields"][] = "calledstationid";
$tdataradacct[".inlineEditFields"][] = "callingstationid";
$tdataradacct[".inlineEditFields"][] = "acctterminatecause";
$tdataradacct[".inlineEditFields"][] = "servicetype";
$tdataradacct[".inlineEditFields"][] = "framedprotocol";
$tdataradacct[".inlineEditFields"][] = "framedipaddress";

$tdataradacct[".exportFields"] = array();
$tdataradacct[".exportFields"][] = "radacctid";
$tdataradacct[".exportFields"][] = "acctsessionid";
$tdataradacct[".exportFields"][] = "acctuniqueid";
$tdataradacct[".exportFields"][] = "username";
$tdataradacct[".exportFields"][] = "groupname";
$tdataradacct[".exportFields"][] = "realm";
$tdataradacct[".exportFields"][] = "nasipaddress";
$tdataradacct[".exportFields"][] = "nasportid";
$tdataradacct[".exportFields"][] = "nasporttype";
$tdataradacct[".exportFields"][] = "acctstarttime";
$tdataradacct[".exportFields"][] = "acctupdatetime";
$tdataradacct[".exportFields"][] = "acctstoptime";
$tdataradacct[".exportFields"][] = "acctinterval";
$tdataradacct[".exportFields"][] = "acctsessiontime";
$tdataradacct[".exportFields"][] = "acctauthentic";
$tdataradacct[".exportFields"][] = "connectinfo_start";
$tdataradacct[".exportFields"][] = "connectinfo_stop";
$tdataradacct[".exportFields"][] = "acctinputoctets";
$tdataradacct[".exportFields"][] = "acctoutputoctets";
$tdataradacct[".exportFields"][] = "calledstationid";
$tdataradacct[".exportFields"][] = "callingstationid";
$tdataradacct[".exportFields"][] = "acctterminatecause";
$tdataradacct[".exportFields"][] = "servicetype";
$tdataradacct[".exportFields"][] = "framedprotocol";
$tdataradacct[".exportFields"][] = "framedipaddress";

$tdataradacct[".importFields"] = array();
$tdataradacct[".importFields"][] = "radacctid";
$tdataradacct[".importFields"][] = "acctsessionid";
$tdataradacct[".importFields"][] = "acctuniqueid";
$tdataradacct[".importFields"][] = "username";
$tdataradacct[".importFields"][] = "groupname";
$tdataradacct[".importFields"][] = "realm";
$tdataradacct[".importFields"][] = "nasipaddress";
$tdataradacct[".importFields"][] = "nasportid";
$tdataradacct[".importFields"][] = "nasporttype";
$tdataradacct[".importFields"][] = "acctstarttime";
$tdataradacct[".importFields"][] = "acctupdatetime";
$tdataradacct[".importFields"][] = "acctstoptime";
$tdataradacct[".importFields"][] = "acctinterval";
$tdataradacct[".importFields"][] = "acctsessiontime";
$tdataradacct[".importFields"][] = "acctauthentic";
$tdataradacct[".importFields"][] = "connectinfo_start";
$tdataradacct[".importFields"][] = "connectinfo_stop";
$tdataradacct[".importFields"][] = "acctinputoctets";
$tdataradacct[".importFields"][] = "acctoutputoctets";
$tdataradacct[".importFields"][] = "calledstationid";
$tdataradacct[".importFields"][] = "callingstationid";
$tdataradacct[".importFields"][] = "acctterminatecause";
$tdataradacct[".importFields"][] = "servicetype";
$tdataradacct[".importFields"][] = "framedprotocol";
$tdataradacct[".importFields"][] = "framedipaddress";

$tdataradacct[".printFields"] = array();
$tdataradacct[".printFields"][] = "radacctid";
$tdataradacct[".printFields"][] = "acctsessionid";
$tdataradacct[".printFields"][] = "acctuniqueid";
$tdataradacct[".printFields"][] = "username";
$tdataradacct[".printFields"][] = "groupname";
$tdataradacct[".printFields"][] = "realm";
$tdataradacct[".printFields"][] = "nasipaddress";
$tdataradacct[".printFields"][] = "nasportid";
$tdataradacct[".printFields"][] = "nasporttype";
$tdataradacct[".printFields"][] = "acctstarttime";
$tdataradacct[".printFields"][] = "acctupdatetime";
$tdataradacct[".printFields"][] = "acctstoptime";
$tdataradacct[".printFields"][] = "acctinterval";
$tdataradacct[".printFields"][] = "acctsessiontime";
$tdataradacct[".printFields"][] = "acctauthentic";
$tdataradacct[".printFields"][] = "connectinfo_start";
$tdataradacct[".printFields"][] = "connectinfo_stop";
$tdataradacct[".printFields"][] = "acctinputoctets";
$tdataradacct[".printFields"][] = "acctoutputoctets";
$tdataradacct[".printFields"][] = "calledstationid";
$tdataradacct[".printFields"][] = "callingstationid";
$tdataradacct[".printFields"][] = "acctterminatecause";
$tdataradacct[".printFields"][] = "servicetype";
$tdataradacct[".printFields"][] = "framedprotocol";
$tdataradacct[".printFields"][] = "framedipaddress";

//	radacctid
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "radacctid";
	$fdata["GoodName"] = "radacctid";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","radacctid");
	$fdata["FieldType"] = 20;

	
		$fdata["AutoInc"] = true;

	
			
		$fdata["bListPage"] = true;

	
	
	
	
		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "radacctid";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "radacctid";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["radacctid"] = $fdata;
//	acctsessionid
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "acctsessionid";
	$fdata["GoodName"] = "acctsessionid";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","acctsessionid");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "acctsessionid";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "acctsessionid";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["acctsessionid"] = $fdata;
//	acctuniqueid
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "acctuniqueid";
	$fdata["GoodName"] = "acctuniqueid";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","acctuniqueid");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "acctuniqueid";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "acctuniqueid";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=32";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["acctuniqueid"] = $fdata;
//	username
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "username";
	$fdata["GoodName"] = "username";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","username");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "username";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "username";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["username"] = $fdata;
//	groupname
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "groupname";
	$fdata["GoodName"] = "groupname";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","groupname");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "groupname";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "groupname";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["groupname"] = $fdata;
//	realm
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "realm";
	$fdata["GoodName"] = "realm";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","realm");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "realm";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "realm";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["realm"] = $fdata;
//	nasipaddress
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "nasipaddress";
	$fdata["GoodName"] = "nasipaddress";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","nasipaddress");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "nasipaddress";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "nasipaddress";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=15";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["nasipaddress"] = $fdata;
//	nasportid
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "nasportid";
	$fdata["GoodName"] = "nasportid";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","nasportid");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "nasportid";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "nasportid";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=15";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["nasportid"] = $fdata;
//	nasporttype
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 9;
	$fdata["strName"] = "nasporttype";
	$fdata["GoodName"] = "nasporttype";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","nasporttype");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "nasporttype";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "nasporttype";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=32";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["nasporttype"] = $fdata;
//	acctstarttime
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 10;
	$fdata["strName"] = "acctstarttime";
	$fdata["GoodName"] = "acctstarttime";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","acctstarttime");
	$fdata["FieldType"] = 135;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "acctstarttime";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "acctstarttime";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Short Date");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Date");

		$edata["ShowTime"] = true;

	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
		$edata["DateEditType"] = 13;
	$edata["InitialYearFactor"] = 100;
	$edata["LastYearFactor"] = 10;

	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings




	$tdataradacct["acctstarttime"] = $fdata;
//	acctupdatetime
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 11;
	$fdata["strName"] = "acctupdatetime";
	$fdata["GoodName"] = "acctupdatetime";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","acctupdatetime");
	$fdata["FieldType"] = 135;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "acctupdatetime";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "acctupdatetime";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Short Date");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Date");

		$edata["ShowTime"] = true;

	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
		$edata["DateEditType"] = 13;
	$edata["InitialYearFactor"] = 100;
	$edata["LastYearFactor"] = 10;

	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings




	$tdataradacct["acctupdatetime"] = $fdata;
//	acctstoptime
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 12;
	$fdata["strName"] = "acctstoptime";
	$fdata["GoodName"] = "acctstoptime";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","acctstoptime");
	$fdata["FieldType"] = 135;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "acctstoptime";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "acctstoptime";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Short Date");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Date");

		$edata["ShowTime"] = true;

	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
		$edata["DateEditType"] = 13;
	$edata["InitialYearFactor"] = 100;
	$edata["LastYearFactor"] = 10;

	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings




	$tdataradacct["acctstoptime"] = $fdata;
//	acctinterval
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 13;
	$fdata["strName"] = "acctinterval";
	$fdata["GoodName"] = "acctinterval";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","acctinterval");
	$fdata["FieldType"] = 3;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "acctinterval";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "acctinterval";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["acctinterval"] = $fdata;
//	acctsessiontime
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 14;
	$fdata["strName"] = "acctsessiontime";
	$fdata["GoodName"] = "acctsessiontime";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","acctsessiontime");
	$fdata["FieldType"] = 3;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "acctsessiontime";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "acctsessiontime";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["acctsessiontime"] = $fdata;
//	acctauthentic
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 15;
	$fdata["strName"] = "acctauthentic";
	$fdata["GoodName"] = "acctauthentic";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","acctauthentic");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "acctauthentic";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "acctauthentic";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=32";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["acctauthentic"] = $fdata;
//	connectinfo_start
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 16;
	$fdata["strName"] = "connectinfo_start";
	$fdata["GoodName"] = "connectinfo_start";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","connectinfo_start");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "connectinfo_start";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "connectinfo_start";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["connectinfo_start"] = $fdata;
//	connectinfo_stop
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 17;
	$fdata["strName"] = "connectinfo_stop";
	$fdata["GoodName"] = "connectinfo_stop";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","connectinfo_stop");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "connectinfo_stop";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "connectinfo_stop";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["connectinfo_stop"] = $fdata;
//	acctinputoctets
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 18;
	$fdata["strName"] = "acctinputoctets";
	$fdata["GoodName"] = "acctinputoctets";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","acctinputoctets");
	$fdata["FieldType"] = 20;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "acctinputoctets";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "acctinputoctets";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["acctinputoctets"] = $fdata;
//	acctoutputoctets
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 19;
	$fdata["strName"] = "acctoutputoctets";
	$fdata["GoodName"] = "acctoutputoctets";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","acctoutputoctets");
	$fdata["FieldType"] = 20;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "acctoutputoctets";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "acctoutputoctets";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["acctoutputoctets"] = $fdata;
//	calledstationid
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 20;
	$fdata["strName"] = "calledstationid";
	$fdata["GoodName"] = "calledstationid";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","calledstationid");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "calledstationid";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "calledstationid";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["calledstationid"] = $fdata;
//	callingstationid
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 21;
	$fdata["strName"] = "callingstationid";
	$fdata["GoodName"] = "callingstationid";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","callingstationid");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "callingstationid";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "callingstationid";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["callingstationid"] = $fdata;
//	acctterminatecause
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 22;
	$fdata["strName"] = "acctterminatecause";
	$fdata["GoodName"] = "acctterminatecause";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","acctterminatecause");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "acctterminatecause";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "acctterminatecause";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=32";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["acctterminatecause"] = $fdata;
//	servicetype
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 23;
	$fdata["strName"] = "servicetype";
	$fdata["GoodName"] = "servicetype";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","servicetype");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "servicetype";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "servicetype";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=32";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["servicetype"] = $fdata;
//	framedprotocol
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 24;
	$fdata["strName"] = "framedprotocol";
	$fdata["GoodName"] = "framedprotocol";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","framedprotocol");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "framedprotocol";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "framedprotocol";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=32";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["framedprotocol"] = $fdata;
//	framedipaddress
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 25;
	$fdata["strName"] = "framedipaddress";
	$fdata["GoodName"] = "framedipaddress";
	$fdata["ownerTable"] = "radacct";
	$fdata["Label"] = GetFieldLabel("radacct","framedipaddress");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "framedipaddress";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "framedipaddress";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=15";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradacct["framedipaddress"] = $fdata;


$tables_data["radacct"]=&$tdataradacct;
$field_labels["radacct"] = &$fieldLabelsradacct;
$fieldToolTips["radacct"] = &$fieldToolTipsradacct;
$page_titles["radacct"] = &$pageTitlesradacct;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["radacct"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["radacct"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_radacct()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "radacctid,  	acctsessionid,  	acctuniqueid,  	username,  	groupname,  	realm,  	nasipaddress,  	nasportid,  	nasporttype,  	acctstarttime,  	acctupdatetime,  	acctstoptime,  	acctinterval,  	acctsessiontime,  	acctauthentic,  	connectinfo_start,  	connectinfo_stop,  	acctinputoctets,  	acctoutputoctets,  	calledstationid,  	callingstationid,  	acctterminatecause,  	servicetype,  	framedprotocol,  	framedipaddress";
$proto0["m_strFrom"] = "FROM radacct";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
$proto0["m_strTail"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "radacctid",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto6["m_sql"] = "radacctid";
$proto6["m_srcTableName"] = "radacct";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "acctsessionid",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto8["m_sql"] = "acctsessionid";
$proto8["m_srcTableName"] = "radacct";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "acctuniqueid",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto10["m_sql"] = "acctuniqueid";
$proto10["m_srcTableName"] = "radacct";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "username",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto12["m_sql"] = "username";
$proto12["m_srcTableName"] = "radacct";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "groupname",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto14["m_sql"] = "groupname";
$proto14["m_srcTableName"] = "radacct";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
						$proto16=array();
			$obj = new SQLField(array(
	"m_strName" => "realm",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto16["m_sql"] = "realm";
$proto16["m_srcTableName"] = "radacct";
$proto16["m_expr"]=$obj;
$proto16["m_alias"] = "";
$obj = new SQLFieldListItem($proto16);

$proto0["m_fieldlist"][]=$obj;
						$proto18=array();
			$obj = new SQLField(array(
	"m_strName" => "nasipaddress",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto18["m_sql"] = "nasipaddress";
$proto18["m_srcTableName"] = "radacct";
$proto18["m_expr"]=$obj;
$proto18["m_alias"] = "";
$obj = new SQLFieldListItem($proto18);

$proto0["m_fieldlist"][]=$obj;
						$proto20=array();
			$obj = new SQLField(array(
	"m_strName" => "nasportid",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto20["m_sql"] = "nasportid";
$proto20["m_srcTableName"] = "radacct";
$proto20["m_expr"]=$obj;
$proto20["m_alias"] = "";
$obj = new SQLFieldListItem($proto20);

$proto0["m_fieldlist"][]=$obj;
						$proto22=array();
			$obj = new SQLField(array(
	"m_strName" => "nasporttype",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto22["m_sql"] = "nasporttype";
$proto22["m_srcTableName"] = "radacct";
$proto22["m_expr"]=$obj;
$proto22["m_alias"] = "";
$obj = new SQLFieldListItem($proto22);

$proto0["m_fieldlist"][]=$obj;
						$proto24=array();
			$obj = new SQLField(array(
	"m_strName" => "acctstarttime",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto24["m_sql"] = "acctstarttime";
$proto24["m_srcTableName"] = "radacct";
$proto24["m_expr"]=$obj;
$proto24["m_alias"] = "";
$obj = new SQLFieldListItem($proto24);

$proto0["m_fieldlist"][]=$obj;
						$proto26=array();
			$obj = new SQLField(array(
	"m_strName" => "acctupdatetime",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto26["m_sql"] = "acctupdatetime";
$proto26["m_srcTableName"] = "radacct";
$proto26["m_expr"]=$obj;
$proto26["m_alias"] = "";
$obj = new SQLFieldListItem($proto26);

$proto0["m_fieldlist"][]=$obj;
						$proto28=array();
			$obj = new SQLField(array(
	"m_strName" => "acctstoptime",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto28["m_sql"] = "acctstoptime";
$proto28["m_srcTableName"] = "radacct";
$proto28["m_expr"]=$obj;
$proto28["m_alias"] = "";
$obj = new SQLFieldListItem($proto28);

$proto0["m_fieldlist"][]=$obj;
						$proto30=array();
			$obj = new SQLField(array(
	"m_strName" => "acctinterval",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto30["m_sql"] = "acctinterval";
$proto30["m_srcTableName"] = "radacct";
$proto30["m_expr"]=$obj;
$proto30["m_alias"] = "";
$obj = new SQLFieldListItem($proto30);

$proto0["m_fieldlist"][]=$obj;
						$proto32=array();
			$obj = new SQLField(array(
	"m_strName" => "acctsessiontime",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto32["m_sql"] = "acctsessiontime";
$proto32["m_srcTableName"] = "radacct";
$proto32["m_expr"]=$obj;
$proto32["m_alias"] = "";
$obj = new SQLFieldListItem($proto32);

$proto0["m_fieldlist"][]=$obj;
						$proto34=array();
			$obj = new SQLField(array(
	"m_strName" => "acctauthentic",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto34["m_sql"] = "acctauthentic";
$proto34["m_srcTableName"] = "radacct";
$proto34["m_expr"]=$obj;
$proto34["m_alias"] = "";
$obj = new SQLFieldListItem($proto34);

$proto0["m_fieldlist"][]=$obj;
						$proto36=array();
			$obj = new SQLField(array(
	"m_strName" => "connectinfo_start",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto36["m_sql"] = "connectinfo_start";
$proto36["m_srcTableName"] = "radacct";
$proto36["m_expr"]=$obj;
$proto36["m_alias"] = "";
$obj = new SQLFieldListItem($proto36);

$proto0["m_fieldlist"][]=$obj;
						$proto38=array();
			$obj = new SQLField(array(
	"m_strName" => "connectinfo_stop",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto38["m_sql"] = "connectinfo_stop";
$proto38["m_srcTableName"] = "radacct";
$proto38["m_expr"]=$obj;
$proto38["m_alias"] = "";
$obj = new SQLFieldListItem($proto38);

$proto0["m_fieldlist"][]=$obj;
						$proto40=array();
			$obj = new SQLField(array(
	"m_strName" => "acctinputoctets",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto40["m_sql"] = "acctinputoctets";
$proto40["m_srcTableName"] = "radacct";
$proto40["m_expr"]=$obj;
$proto40["m_alias"] = "";
$obj = new SQLFieldListItem($proto40);

$proto0["m_fieldlist"][]=$obj;
						$proto42=array();
			$obj = new SQLField(array(
	"m_strName" => "acctoutputoctets",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto42["m_sql"] = "acctoutputoctets";
$proto42["m_srcTableName"] = "radacct";
$proto42["m_expr"]=$obj;
$proto42["m_alias"] = "";
$obj = new SQLFieldListItem($proto42);

$proto0["m_fieldlist"][]=$obj;
						$proto44=array();
			$obj = new SQLField(array(
	"m_strName" => "calledstationid",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto44["m_sql"] = "calledstationid";
$proto44["m_srcTableName"] = "radacct";
$proto44["m_expr"]=$obj;
$proto44["m_alias"] = "";
$obj = new SQLFieldListItem($proto44);

$proto0["m_fieldlist"][]=$obj;
						$proto46=array();
			$obj = new SQLField(array(
	"m_strName" => "callingstationid",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto46["m_sql"] = "callingstationid";
$proto46["m_srcTableName"] = "radacct";
$proto46["m_expr"]=$obj;
$proto46["m_alias"] = "";
$obj = new SQLFieldListItem($proto46);

$proto0["m_fieldlist"][]=$obj;
						$proto48=array();
			$obj = new SQLField(array(
	"m_strName" => "acctterminatecause",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto48["m_sql"] = "acctterminatecause";
$proto48["m_srcTableName"] = "radacct";
$proto48["m_expr"]=$obj;
$proto48["m_alias"] = "";
$obj = new SQLFieldListItem($proto48);

$proto0["m_fieldlist"][]=$obj;
						$proto50=array();
			$obj = new SQLField(array(
	"m_strName" => "servicetype",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto50["m_sql"] = "servicetype";
$proto50["m_srcTableName"] = "radacct";
$proto50["m_expr"]=$obj;
$proto50["m_alias"] = "";
$obj = new SQLFieldListItem($proto50);

$proto0["m_fieldlist"][]=$obj;
						$proto52=array();
			$obj = new SQLField(array(
	"m_strName" => "framedprotocol",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto52["m_sql"] = "framedprotocol";
$proto52["m_srcTableName"] = "radacct";
$proto52["m_expr"]=$obj;
$proto52["m_alias"] = "";
$obj = new SQLFieldListItem($proto52);

$proto0["m_fieldlist"][]=$obj;
						$proto54=array();
			$obj = new SQLField(array(
	"m_strName" => "framedipaddress",
	"m_strTable" => "radacct",
	"m_srcTableName" => "radacct"
));

$proto54["m_sql"] = "framedipaddress";
$proto54["m_srcTableName"] = "radacct";
$proto54["m_expr"]=$obj;
$proto54["m_alias"] = "";
$obj = new SQLFieldListItem($proto54);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto56=array();
$proto56["m_link"] = "SQLL_MAIN";
			$proto57=array();
$proto57["m_strName"] = "radacct";
$proto57["m_srcTableName"] = "radacct";
$proto57["m_columns"] = array();
$proto57["m_columns"][] = "radacctid";
$proto57["m_columns"][] = "acctsessionid";
$proto57["m_columns"][] = "acctuniqueid";
$proto57["m_columns"][] = "username";
$proto57["m_columns"][] = "groupname";
$proto57["m_columns"][] = "realm";
$proto57["m_columns"][] = "nasipaddress";
$proto57["m_columns"][] = "nasportid";
$proto57["m_columns"][] = "nasporttype";
$proto57["m_columns"][] = "acctstarttime";
$proto57["m_columns"][] = "acctupdatetime";
$proto57["m_columns"][] = "acctstoptime";
$proto57["m_columns"][] = "acctinterval";
$proto57["m_columns"][] = "acctsessiontime";
$proto57["m_columns"][] = "acctauthentic";
$proto57["m_columns"][] = "connectinfo_start";
$proto57["m_columns"][] = "connectinfo_stop";
$proto57["m_columns"][] = "acctinputoctets";
$proto57["m_columns"][] = "acctoutputoctets";
$proto57["m_columns"][] = "calledstationid";
$proto57["m_columns"][] = "callingstationid";
$proto57["m_columns"][] = "acctterminatecause";
$proto57["m_columns"][] = "servicetype";
$proto57["m_columns"][] = "framedprotocol";
$proto57["m_columns"][] = "framedipaddress";
$obj = new SQLTable($proto57);

$proto56["m_table"] = $obj;
$proto56["m_sql"] = "radacct";
$proto56["m_alias"] = "";
$proto56["m_srcTableName"] = "radacct";
$proto58=array();
$proto58["m_sql"] = "";
$proto58["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto58["m_column"]=$obj;
$proto58["m_contained"] = array();
$proto58["m_strCase"] = "";
$proto58["m_havingmode"] = false;
$proto58["m_inBrackets"] = false;
$proto58["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto58);

$proto56["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto56);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="radacct";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_radacct = createSqlQuery_radacct();


	
		;

																									

$tdataradacct[".sqlquery"] = $queryData_radacct;

$tableEvents["radacct"] = new eventsBase;
$tdataradacct[".hasEvents"] = false;

?>