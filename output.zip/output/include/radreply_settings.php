<?php
require_once(getabspath("classes/cipherer.php"));




$tdataradreply = array();
	$tdataradreply[".truncateText"] = true;
	$tdataradreply[".NumberOfChars"] = 80;
	$tdataradreply[".ShortName"] = "radreply";
	$tdataradreply[".OwnerID"] = "";
	$tdataradreply[".OriginalTable"] = "radreply";

//	field labels
$fieldLabelsradreply = array();
$fieldToolTipsradreply = array();
$pageTitlesradreply = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsradreply["English"] = array();
	$fieldToolTipsradreply["English"] = array();
	$pageTitlesradreply["English"] = array();
	$fieldLabelsradreply["English"]["id"] = "Id";
	$fieldToolTipsradreply["English"]["id"] = "";
	$fieldLabelsradreply["English"]["username"] = "Username";
	$fieldToolTipsradreply["English"]["username"] = "";
	$fieldLabelsradreply["English"]["attribute"] = "Attribute";
	$fieldToolTipsradreply["English"]["attribute"] = "";
	$fieldLabelsradreply["English"]["op"] = "Op";
	$fieldToolTipsradreply["English"]["op"] = "";
	$fieldLabelsradreply["English"]["value"] = "Value";
	$fieldToolTipsradreply["English"]["value"] = "";
	if (count($fieldToolTipsradreply["English"]))
		$tdataradreply[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsradreply[""] = array();
	$fieldToolTipsradreply[""] = array();
	$pageTitlesradreply[""] = array();
	if (count($fieldToolTipsradreply[""]))
		$tdataradreply[".isUseToolTips"] = true;
}


	$tdataradreply[".NCSearch"] = true;



$tdataradreply[".shortTableName"] = "radreply";
$tdataradreply[".nSecOptions"] = 0;
$tdataradreply[".recsPerRowPrint"] = 1;
$tdataradreply[".mainTableOwnerID"] = "";
$tdataradreply[".moveNext"] = 1;
$tdataradreply[".entityType"] = 0;

$tdataradreply[".strOriginalTableName"] = "radreply";

	



$tdataradreply[".showAddInPopup"] = false;

$tdataradreply[".showEditInPopup"] = false;

$tdataradreply[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdataradreply[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataradreply[".fieldsForRegister"] = array();

$tdataradreply[".listAjax"] = false;

	$tdataradreply[".audit"] = false;

	$tdataradreply[".locking"] = false;

$tdataradreply[".edit"] = true;
$tdataradreply[".afterEditAction"] = 1;
$tdataradreply[".closePopupAfterEdit"] = 1;
$tdataradreply[".afterEditActionDetTable"] = "";

$tdataradreply[".add"] = true;
$tdataradreply[".afterAddAction"] = 1;
$tdataradreply[".closePopupAfterAdd"] = 1;
$tdataradreply[".afterAddActionDetTable"] = "";

$tdataradreply[".list"] = true;

$tdataradreply[".view"] = true;

$tdataradreply[".import"] = true;

$tdataradreply[".exportTo"] = true;

$tdataradreply[".printFriendly"] = true;

$tdataradreply[".delete"] = true;

$tdataradreply[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdataradreply[".searchSaving"] = false;
//

$tdataradreply[".showSearchPanel"] = true;
		$tdataradreply[".flexibleSearch"] = true;

$tdataradreply[".isUseAjaxSuggest"] = true;

$tdataradreply[".rowHighlite"] = true;



$tdataradreply[".addPageEvents"] = false;

// use timepicker for search panel
$tdataradreply[".isUseTimeForSearch"] = false;





$tdataradreply[".allSearchFields"] = array();
$tdataradreply[".filterFields"] = array();
$tdataradreply[".requiredSearchFields"] = array();

$tdataradreply[".allSearchFields"][] = "id";
	$tdataradreply[".allSearchFields"][] = "username";
	$tdataradreply[".allSearchFields"][] = "attribute";
	$tdataradreply[".allSearchFields"][] = "op";
	$tdataradreply[".allSearchFields"][] = "value";
	

$tdataradreply[".googleLikeFields"] = array();
$tdataradreply[".googleLikeFields"][] = "id";
$tdataradreply[".googleLikeFields"][] = "username";
$tdataradreply[".googleLikeFields"][] = "attribute";
$tdataradreply[".googleLikeFields"][] = "op";
$tdataradreply[".googleLikeFields"][] = "value";


$tdataradreply[".advSearchFields"] = array();
$tdataradreply[".advSearchFields"][] = "id";
$tdataradreply[".advSearchFields"][] = "username";
$tdataradreply[".advSearchFields"][] = "attribute";
$tdataradreply[".advSearchFields"][] = "op";
$tdataradreply[".advSearchFields"][] = "value";

$tdataradreply[".tableType"] = "list";

$tdataradreply[".printerPageOrientation"] = 0;
$tdataradreply[".nPrinterPageScale"] = 100;

$tdataradreply[".nPrinterSplitRecords"] = 40;

$tdataradreply[".nPrinterPDFSplitRecords"] = 40;



$tdataradreply[".geocodingEnabled"] = false;





$tdataradreply[".listGridLayout"] = 3;





// view page pdf

// print page pdf


$tdataradreply[".pageSize"] = 20;

$tdataradreply[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataradreply[".strOrderBy"] = $tstrOrderBy;

$tdataradreply[".orderindexes"] = array();

$tdataradreply[".sqlHead"] = "SELECT id,  	username,  	attribute,  	op,  	`value`";
$tdataradreply[".sqlFrom"] = "FROM radreply";
$tdataradreply[".sqlWhereExpr"] = "";
$tdataradreply[".sqlTail"] = "";











//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataradreply[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataradreply[".arrGroupsPerPage"] = $arrGPP;

$tdataradreply[".highlightSearchResults"] = true;

$tableKeysradreply = array();
$tableKeysradreply[] = "id";
$tdataradreply[".Keys"] = $tableKeysradreply;

$tdataradreply[".listFields"] = array();
$tdataradreply[".listFields"][] = "id";
$tdataradreply[".listFields"][] = "username";
$tdataradreply[".listFields"][] = "attribute";
$tdataradreply[".listFields"][] = "op";
$tdataradreply[".listFields"][] = "value";

$tdataradreply[".hideMobileList"] = array();


$tdataradreply[".viewFields"] = array();
$tdataradreply[".viewFields"][] = "id";
$tdataradreply[".viewFields"][] = "username";
$tdataradreply[".viewFields"][] = "attribute";
$tdataradreply[".viewFields"][] = "op";
$tdataradreply[".viewFields"][] = "value";

$tdataradreply[".addFields"] = array();
$tdataradreply[".addFields"][] = "username";
$tdataradreply[".addFields"][] = "attribute";
$tdataradreply[".addFields"][] = "op";
$tdataradreply[".addFields"][] = "value";

$tdataradreply[".masterListFields"] = array();
$tdataradreply[".masterListFields"][] = "id";
$tdataradreply[".masterListFields"][] = "username";
$tdataradreply[".masterListFields"][] = "attribute";
$tdataradreply[".masterListFields"][] = "op";
$tdataradreply[".masterListFields"][] = "value";

$tdataradreply[".inlineAddFields"] = array();
$tdataradreply[".inlineAddFields"][] = "username";
$tdataradreply[".inlineAddFields"][] = "attribute";
$tdataradreply[".inlineAddFields"][] = "op";
$tdataradreply[".inlineAddFields"][] = "value";

$tdataradreply[".editFields"] = array();
$tdataradreply[".editFields"][] = "username";
$tdataradreply[".editFields"][] = "attribute";
$tdataradreply[".editFields"][] = "op";
$tdataradreply[".editFields"][] = "value";

$tdataradreply[".inlineEditFields"] = array();
$tdataradreply[".inlineEditFields"][] = "username";
$tdataradreply[".inlineEditFields"][] = "attribute";
$tdataradreply[".inlineEditFields"][] = "op";
$tdataradreply[".inlineEditFields"][] = "value";

$tdataradreply[".exportFields"] = array();
$tdataradreply[".exportFields"][] = "id";
$tdataradreply[".exportFields"][] = "username";
$tdataradreply[".exportFields"][] = "attribute";
$tdataradreply[".exportFields"][] = "op";
$tdataradreply[".exportFields"][] = "value";

$tdataradreply[".importFields"] = array();
$tdataradreply[".importFields"][] = "id";
$tdataradreply[".importFields"][] = "username";
$tdataradreply[".importFields"][] = "attribute";
$tdataradreply[".importFields"][] = "op";
$tdataradreply[".importFields"][] = "value";

$tdataradreply[".printFields"] = array();
$tdataradreply[".printFields"][] = "id";
$tdataradreply[".printFields"][] = "username";
$tdataradreply[".printFields"][] = "attribute";
$tdataradreply[".printFields"][] = "op";
$tdataradreply[".printFields"][] = "value";

//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "radreply";
	$fdata["Label"] = GetFieldLabel("radreply","id");
	$fdata["FieldType"] = 3;

	
		$fdata["AutoInc"] = true;

	
			
		$fdata["bListPage"] = true;

	
	
	
	
		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "id";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradreply["id"] = $fdata;
//	username
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "username";
	$fdata["GoodName"] = "username";
	$fdata["ownerTable"] = "radreply";
	$fdata["Label"] = GetFieldLabel("radreply","username");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "username";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "username";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradreply["username"] = $fdata;
//	attribute
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "attribute";
	$fdata["GoodName"] = "attribute";
	$fdata["ownerTable"] = "radreply";
	$fdata["Label"] = GetFieldLabel("radreply","attribute");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "attribute";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "attribute";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradreply["attribute"] = $fdata;
//	op
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "op";
	$fdata["GoodName"] = "op";
	$fdata["ownerTable"] = "radreply";
	$fdata["Label"] = GetFieldLabel("radreply","op");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "op";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "op";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=2";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradreply["op"] = $fdata;
//	value
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "value";
	$fdata["GoodName"] = "value";
	$fdata["ownerTable"] = "radreply";
	$fdata["Label"] = GetFieldLabel("radreply","value");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "value";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`value`";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=253";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradreply["value"] = $fdata;


$tables_data["radreply"]=&$tdataradreply;
$field_labels["radreply"] = &$fieldLabelsradreply;
$fieldToolTips["radreply"] = &$fieldToolTipsradreply;
$page_titles["radreply"] = &$pageTitlesradreply;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["radreply"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["radreply"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_radreply()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	username,  	attribute,  	op,  	`value`";
$proto0["m_strFrom"] = "FROM radreply";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
$proto0["m_strTail"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "radreply",
	"m_srcTableName" => "radreply"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "radreply";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "username",
	"m_strTable" => "radreply",
	"m_srcTableName" => "radreply"
));

$proto8["m_sql"] = "username";
$proto8["m_srcTableName"] = "radreply";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "attribute",
	"m_strTable" => "radreply",
	"m_srcTableName" => "radreply"
));

$proto10["m_sql"] = "attribute";
$proto10["m_srcTableName"] = "radreply";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "op",
	"m_strTable" => "radreply",
	"m_srcTableName" => "radreply"
));

$proto12["m_sql"] = "op";
$proto12["m_srcTableName"] = "radreply";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "value",
	"m_strTable" => "radreply",
	"m_srcTableName" => "radreply"
));

$proto14["m_sql"] = "`value`";
$proto14["m_srcTableName"] = "radreply";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto16=array();
$proto16["m_link"] = "SQLL_MAIN";
			$proto17=array();
$proto17["m_strName"] = "radreply";
$proto17["m_srcTableName"] = "radreply";
$proto17["m_columns"] = array();
$proto17["m_columns"][] = "id";
$proto17["m_columns"][] = "username";
$proto17["m_columns"][] = "attribute";
$proto17["m_columns"][] = "op";
$proto17["m_columns"][] = "value";
$obj = new SQLTable($proto17);

$proto16["m_table"] = $obj;
$proto16["m_sql"] = "radreply";
$proto16["m_alias"] = "";
$proto16["m_srcTableName"] = "radreply";
$proto18=array();
$proto18["m_sql"] = "";
$proto18["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto18["m_column"]=$obj;
$proto18["m_contained"] = array();
$proto18["m_strCase"] = "";
$proto18["m_havingmode"] = false;
$proto18["m_inBrackets"] = false;
$proto18["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto18);

$proto16["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto16);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="radreply";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_radreply = createSqlQuery_radreply();


	
		;

					

$tdataradreply[".sqlquery"] = $queryData_radreply;

$tableEvents["radreply"] = new eventsBase;
$tdataradreply[".hasEvents"] = false;

?>