<?php
require_once(getabspath("classes/cipherer.php"));




$tdataradgroupreply = array();
	$tdataradgroupreply[".truncateText"] = true;
	$tdataradgroupreply[".NumberOfChars"] = 80;
	$tdataradgroupreply[".ShortName"] = "radgroupreply";
	$tdataradgroupreply[".OwnerID"] = "";
	$tdataradgroupreply[".OriginalTable"] = "radgroupreply";

//	field labels
$fieldLabelsradgroupreply = array();
$fieldToolTipsradgroupreply = array();
$pageTitlesradgroupreply = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsradgroupreply["English"] = array();
	$fieldToolTipsradgroupreply["English"] = array();
	$pageTitlesradgroupreply["English"] = array();
	$fieldLabelsradgroupreply["English"]["id"] = "Id";
	$fieldToolTipsradgroupreply["English"]["id"] = "";
	$fieldLabelsradgroupreply["English"]["groupname"] = "Groupname";
	$fieldToolTipsradgroupreply["English"]["groupname"] = "";
	$fieldLabelsradgroupreply["English"]["attribute"] = "Attribute";
	$fieldToolTipsradgroupreply["English"]["attribute"] = "";
	$fieldLabelsradgroupreply["English"]["op"] = "Op";
	$fieldToolTipsradgroupreply["English"]["op"] = "";
	$fieldLabelsradgroupreply["English"]["value"] = "Value";
	$fieldToolTipsradgroupreply["English"]["value"] = "";
	if (count($fieldToolTipsradgroupreply["English"]))
		$tdataradgroupreply[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsradgroupreply[""] = array();
	$fieldToolTipsradgroupreply[""] = array();
	$pageTitlesradgroupreply[""] = array();
	if (count($fieldToolTipsradgroupreply[""]))
		$tdataradgroupreply[".isUseToolTips"] = true;
}


	$tdataradgroupreply[".NCSearch"] = true;



$tdataradgroupreply[".shortTableName"] = "radgroupreply";
$tdataradgroupreply[".nSecOptions"] = 0;
$tdataradgroupreply[".recsPerRowPrint"] = 1;
$tdataradgroupreply[".mainTableOwnerID"] = "";
$tdataradgroupreply[".moveNext"] = 1;
$tdataradgroupreply[".entityType"] = 0;

$tdataradgroupreply[".strOriginalTableName"] = "radgroupreply";

	



$tdataradgroupreply[".showAddInPopup"] = false;

$tdataradgroupreply[".showEditInPopup"] = false;

$tdataradgroupreply[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdataradgroupreply[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataradgroupreply[".fieldsForRegister"] = array();

$tdataradgroupreply[".listAjax"] = false;

	$tdataradgroupreply[".audit"] = false;

	$tdataradgroupreply[".locking"] = false;

$tdataradgroupreply[".edit"] = true;
$tdataradgroupreply[".afterEditAction"] = 1;
$tdataradgroupreply[".closePopupAfterEdit"] = 1;
$tdataradgroupreply[".afterEditActionDetTable"] = "";

$tdataradgroupreply[".add"] = true;
$tdataradgroupreply[".afterAddAction"] = 1;
$tdataradgroupreply[".closePopupAfterAdd"] = 1;
$tdataradgroupreply[".afterAddActionDetTable"] = "";

$tdataradgroupreply[".list"] = true;

$tdataradgroupreply[".view"] = true;

$tdataradgroupreply[".import"] = true;

$tdataradgroupreply[".exportTo"] = true;

$tdataradgroupreply[".printFriendly"] = true;

$tdataradgroupreply[".delete"] = true;

$tdataradgroupreply[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdataradgroupreply[".searchSaving"] = false;
//

$tdataradgroupreply[".showSearchPanel"] = true;
		$tdataradgroupreply[".flexibleSearch"] = true;

$tdataradgroupreply[".isUseAjaxSuggest"] = true;

$tdataradgroupreply[".rowHighlite"] = true;



$tdataradgroupreply[".addPageEvents"] = false;

// use timepicker for search panel
$tdataradgroupreply[".isUseTimeForSearch"] = false;





$tdataradgroupreply[".allSearchFields"] = array();
$tdataradgroupreply[".filterFields"] = array();
$tdataradgroupreply[".requiredSearchFields"] = array();

$tdataradgroupreply[".allSearchFields"][] = "id";
	$tdataradgroupreply[".allSearchFields"][] = "groupname";
	$tdataradgroupreply[".allSearchFields"][] = "attribute";
	$tdataradgroupreply[".allSearchFields"][] = "op";
	$tdataradgroupreply[".allSearchFields"][] = "value";
	

$tdataradgroupreply[".googleLikeFields"] = array();
$tdataradgroupreply[".googleLikeFields"][] = "id";
$tdataradgroupreply[".googleLikeFields"][] = "groupname";
$tdataradgroupreply[".googleLikeFields"][] = "attribute";
$tdataradgroupreply[".googleLikeFields"][] = "op";
$tdataradgroupreply[".googleLikeFields"][] = "value";


$tdataradgroupreply[".advSearchFields"] = array();
$tdataradgroupreply[".advSearchFields"][] = "id";
$tdataradgroupreply[".advSearchFields"][] = "groupname";
$tdataradgroupreply[".advSearchFields"][] = "attribute";
$tdataradgroupreply[".advSearchFields"][] = "op";
$tdataradgroupreply[".advSearchFields"][] = "value";

$tdataradgroupreply[".tableType"] = "list";

$tdataradgroupreply[".printerPageOrientation"] = 0;
$tdataradgroupreply[".nPrinterPageScale"] = 100;

$tdataradgroupreply[".nPrinterSplitRecords"] = 40;

$tdataradgroupreply[".nPrinterPDFSplitRecords"] = 40;



$tdataradgroupreply[".geocodingEnabled"] = false;





$tdataradgroupreply[".listGridLayout"] = 3;





// view page pdf

// print page pdf


$tdataradgroupreply[".pageSize"] = 20;

$tdataradgroupreply[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataradgroupreply[".strOrderBy"] = $tstrOrderBy;

$tdataradgroupreply[".orderindexes"] = array();

$tdataradgroupreply[".sqlHead"] = "SELECT id,  	groupname,  	attribute,  	op,  	`value`";
$tdataradgroupreply[".sqlFrom"] = "FROM radgroupreply";
$tdataradgroupreply[".sqlWhereExpr"] = "";
$tdataradgroupreply[".sqlTail"] = "";











//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataradgroupreply[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataradgroupreply[".arrGroupsPerPage"] = $arrGPP;

$tdataradgroupreply[".highlightSearchResults"] = true;

$tableKeysradgroupreply = array();
$tableKeysradgroupreply[] = "id";
$tdataradgroupreply[".Keys"] = $tableKeysradgroupreply;

$tdataradgroupreply[".listFields"] = array();
$tdataradgroupreply[".listFields"][] = "id";
$tdataradgroupreply[".listFields"][] = "groupname";
$tdataradgroupreply[".listFields"][] = "attribute";
$tdataradgroupreply[".listFields"][] = "op";
$tdataradgroupreply[".listFields"][] = "value";

$tdataradgroupreply[".hideMobileList"] = array();


$tdataradgroupreply[".viewFields"] = array();
$tdataradgroupreply[".viewFields"][] = "id";
$tdataradgroupreply[".viewFields"][] = "groupname";
$tdataradgroupreply[".viewFields"][] = "attribute";
$tdataradgroupreply[".viewFields"][] = "op";
$tdataradgroupreply[".viewFields"][] = "value";

$tdataradgroupreply[".addFields"] = array();
$tdataradgroupreply[".addFields"][] = "groupname";
$tdataradgroupreply[".addFields"][] = "attribute";
$tdataradgroupreply[".addFields"][] = "op";
$tdataradgroupreply[".addFields"][] = "value";

$tdataradgroupreply[".masterListFields"] = array();
$tdataradgroupreply[".masterListFields"][] = "id";
$tdataradgroupreply[".masterListFields"][] = "groupname";
$tdataradgroupreply[".masterListFields"][] = "attribute";
$tdataradgroupreply[".masterListFields"][] = "op";
$tdataradgroupreply[".masterListFields"][] = "value";

$tdataradgroupreply[".inlineAddFields"] = array();
$tdataradgroupreply[".inlineAddFields"][] = "groupname";
$tdataradgroupreply[".inlineAddFields"][] = "attribute";
$tdataradgroupreply[".inlineAddFields"][] = "op";
$tdataradgroupreply[".inlineAddFields"][] = "value";

$tdataradgroupreply[".editFields"] = array();
$tdataradgroupreply[".editFields"][] = "groupname";
$tdataradgroupreply[".editFields"][] = "attribute";
$tdataradgroupreply[".editFields"][] = "op";
$tdataradgroupreply[".editFields"][] = "value";

$tdataradgroupreply[".inlineEditFields"] = array();
$tdataradgroupreply[".inlineEditFields"][] = "groupname";
$tdataradgroupreply[".inlineEditFields"][] = "attribute";
$tdataradgroupreply[".inlineEditFields"][] = "op";
$tdataradgroupreply[".inlineEditFields"][] = "value";

$tdataradgroupreply[".exportFields"] = array();
$tdataradgroupreply[".exportFields"][] = "id";
$tdataradgroupreply[".exportFields"][] = "groupname";
$tdataradgroupreply[".exportFields"][] = "attribute";
$tdataradgroupreply[".exportFields"][] = "op";
$tdataradgroupreply[".exportFields"][] = "value";

$tdataradgroupreply[".importFields"] = array();
$tdataradgroupreply[".importFields"][] = "id";
$tdataradgroupreply[".importFields"][] = "groupname";
$tdataradgroupreply[".importFields"][] = "attribute";
$tdataradgroupreply[".importFields"][] = "op";
$tdataradgroupreply[".importFields"][] = "value";

$tdataradgroupreply[".printFields"] = array();
$tdataradgroupreply[".printFields"][] = "id";
$tdataradgroupreply[".printFields"][] = "groupname";
$tdataradgroupreply[".printFields"][] = "attribute";
$tdataradgroupreply[".printFields"][] = "op";
$tdataradgroupreply[".printFields"][] = "value";

//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "radgroupreply";
	$fdata["Label"] = GetFieldLabel("radgroupreply","id");
	$fdata["FieldType"] = 3;

	
		$fdata["AutoInc"] = true;

	
			
		$fdata["bListPage"] = true;

	
	
	
	
		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "id";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradgroupreply["id"] = $fdata;
//	groupname
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "groupname";
	$fdata["GoodName"] = "groupname";
	$fdata["ownerTable"] = "radgroupreply";
	$fdata["Label"] = GetFieldLabel("radgroupreply","groupname");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "groupname";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "groupname";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradgroupreply["groupname"] = $fdata;
//	attribute
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "attribute";
	$fdata["GoodName"] = "attribute";
	$fdata["ownerTable"] = "radgroupreply";
	$fdata["Label"] = GetFieldLabel("radgroupreply","attribute");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "attribute";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "attribute";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradgroupreply["attribute"] = $fdata;
//	op
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "op";
	$fdata["GoodName"] = "op";
	$fdata["ownerTable"] = "radgroupreply";
	$fdata["Label"] = GetFieldLabel("radgroupreply","op");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "op";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "op";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=2";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradgroupreply["op"] = $fdata;
//	value
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "value";
	$fdata["GoodName"] = "value";
	$fdata["ownerTable"] = "radgroupreply";
	$fdata["Label"] = GetFieldLabel("radgroupreply","value");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "value";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`value`";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=253";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradgroupreply["value"] = $fdata;


$tables_data["radgroupreply"]=&$tdataradgroupreply;
$field_labels["radgroupreply"] = &$fieldLabelsradgroupreply;
$fieldToolTips["radgroupreply"] = &$fieldToolTipsradgroupreply;
$page_titles["radgroupreply"] = &$pageTitlesradgroupreply;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["radgroupreply"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["radgroupreply"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_radgroupreply()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	groupname,  	attribute,  	op,  	`value`";
$proto0["m_strFrom"] = "FROM radgroupreply";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
$proto0["m_strTail"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "radgroupreply",
	"m_srcTableName" => "radgroupreply"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "radgroupreply";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "groupname",
	"m_strTable" => "radgroupreply",
	"m_srcTableName" => "radgroupreply"
));

$proto8["m_sql"] = "groupname";
$proto8["m_srcTableName"] = "radgroupreply";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "attribute",
	"m_strTable" => "radgroupreply",
	"m_srcTableName" => "radgroupreply"
));

$proto10["m_sql"] = "attribute";
$proto10["m_srcTableName"] = "radgroupreply";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "op",
	"m_strTable" => "radgroupreply",
	"m_srcTableName" => "radgroupreply"
));

$proto12["m_sql"] = "op";
$proto12["m_srcTableName"] = "radgroupreply";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "value",
	"m_strTable" => "radgroupreply",
	"m_srcTableName" => "radgroupreply"
));

$proto14["m_sql"] = "`value`";
$proto14["m_srcTableName"] = "radgroupreply";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto16=array();
$proto16["m_link"] = "SQLL_MAIN";
			$proto17=array();
$proto17["m_strName"] = "radgroupreply";
$proto17["m_srcTableName"] = "radgroupreply";
$proto17["m_columns"] = array();
$proto17["m_columns"][] = "id";
$proto17["m_columns"][] = "groupname";
$proto17["m_columns"][] = "attribute";
$proto17["m_columns"][] = "op";
$proto17["m_columns"][] = "value";
$obj = new SQLTable($proto17);

$proto16["m_table"] = $obj;
$proto16["m_sql"] = "radgroupreply";
$proto16["m_alias"] = "";
$proto16["m_srcTableName"] = "radgroupreply";
$proto18=array();
$proto18["m_sql"] = "";
$proto18["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto18["m_column"]=$obj;
$proto18["m_contained"] = array();
$proto18["m_strCase"] = "";
$proto18["m_havingmode"] = false;
$proto18["m_inBrackets"] = false;
$proto18["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto18);

$proto16["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto16);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="radgroupreply";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_radgroupreply = createSqlQuery_radgroupreply();


	
		;

					

$tdataradgroupreply[".sqlquery"] = $queryData_radgroupreply;

$tableEvents["radgroupreply"] = new eventsBase;
$tdataradgroupreply[".hasEvents"] = false;

?>