<?php
require_once(getabspath("classes/cipherer.php"));




$tdatanas = array();
	$tdatanas[".truncateText"] = true;
	$tdatanas[".NumberOfChars"] = 80;
	$tdatanas[".ShortName"] = "nas";
	$tdatanas[".OwnerID"] = "";
	$tdatanas[".OriginalTable"] = "nas";

//	field labels
$fieldLabelsnas = array();
$fieldToolTipsnas = array();
$pageTitlesnas = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsnas["English"] = array();
	$fieldToolTipsnas["English"] = array();
	$pageTitlesnas["English"] = array();
	$fieldLabelsnas["English"]["id"] = "Id";
	$fieldToolTipsnas["English"]["id"] = "";
	$fieldLabelsnas["English"]["nasname"] = "Nasname";
	$fieldToolTipsnas["English"]["nasname"] = "";
	$fieldLabelsnas["English"]["shortname"] = "Shortname";
	$fieldToolTipsnas["English"]["shortname"] = "";
	$fieldLabelsnas["English"]["type"] = "Type";
	$fieldToolTipsnas["English"]["type"] = "";
	$fieldLabelsnas["English"]["ports"] = "Ports";
	$fieldToolTipsnas["English"]["ports"] = "";
	$fieldLabelsnas["English"]["secret"] = "Secret";
	$fieldToolTipsnas["English"]["secret"] = "";
	$fieldLabelsnas["English"]["server"] = "Server";
	$fieldToolTipsnas["English"]["server"] = "";
	$fieldLabelsnas["English"]["community"] = "Community";
	$fieldToolTipsnas["English"]["community"] = "";
	$fieldLabelsnas["English"]["description"] = "Description";
	$fieldToolTipsnas["English"]["description"] = "";
	if (count($fieldToolTipsnas["English"]))
		$tdatanas[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsnas[""] = array();
	$fieldToolTipsnas[""] = array();
	$pageTitlesnas[""] = array();
	if (count($fieldToolTipsnas[""]))
		$tdatanas[".isUseToolTips"] = true;
}


	$tdatanas[".NCSearch"] = true;



$tdatanas[".shortTableName"] = "nas";
$tdatanas[".nSecOptions"] = 0;
$tdatanas[".recsPerRowPrint"] = 1;
$tdatanas[".mainTableOwnerID"] = "";
$tdatanas[".moveNext"] = 1;
$tdatanas[".entityType"] = 0;

$tdatanas[".strOriginalTableName"] = "nas";

	



$tdatanas[".showAddInPopup"] = false;

$tdatanas[".showEditInPopup"] = false;

$tdatanas[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdatanas[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdatanas[".fieldsForRegister"] = array();

$tdatanas[".listAjax"] = false;

	$tdatanas[".audit"] = false;

	$tdatanas[".locking"] = false;

$tdatanas[".edit"] = true;
$tdatanas[".afterEditAction"] = 1;
$tdatanas[".closePopupAfterEdit"] = 1;
$tdatanas[".afterEditActionDetTable"] = "";

$tdatanas[".add"] = true;
$tdatanas[".afterAddAction"] = 1;
$tdatanas[".closePopupAfterAdd"] = 1;
$tdatanas[".afterAddActionDetTable"] = "";

$tdatanas[".list"] = true;

$tdatanas[".view"] = true;

$tdatanas[".import"] = true;

$tdatanas[".exportTo"] = true;

$tdatanas[".printFriendly"] = true;

$tdatanas[".delete"] = true;

$tdatanas[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdatanas[".searchSaving"] = false;
//

$tdatanas[".showSearchPanel"] = true;
		$tdatanas[".flexibleSearch"] = true;

$tdatanas[".isUseAjaxSuggest"] = true;

$tdatanas[".rowHighlite"] = true;



$tdatanas[".addPageEvents"] = false;

// use timepicker for search panel
$tdatanas[".isUseTimeForSearch"] = false;



$tdatanas[".badgeColor"] = "EDCA00";


$tdatanas[".allSearchFields"] = array();
$tdatanas[".filterFields"] = array();
$tdatanas[".requiredSearchFields"] = array();

$tdatanas[".allSearchFields"][] = "id";
	$tdatanas[".allSearchFields"][] = "nasname";
	$tdatanas[".allSearchFields"][] = "shortname";
	$tdatanas[".allSearchFields"][] = "type";
	$tdatanas[".allSearchFields"][] = "ports";
	$tdatanas[".allSearchFields"][] = "secret";
	$tdatanas[".allSearchFields"][] = "server";
	$tdatanas[".allSearchFields"][] = "community";
	$tdatanas[".allSearchFields"][] = "description";
	

$tdatanas[".googleLikeFields"] = array();
$tdatanas[".googleLikeFields"][] = "id";
$tdatanas[".googleLikeFields"][] = "nasname";
$tdatanas[".googleLikeFields"][] = "shortname";
$tdatanas[".googleLikeFields"][] = "type";
$tdatanas[".googleLikeFields"][] = "ports";
$tdatanas[".googleLikeFields"][] = "secret";
$tdatanas[".googleLikeFields"][] = "server";
$tdatanas[".googleLikeFields"][] = "community";
$tdatanas[".googleLikeFields"][] = "description";


$tdatanas[".advSearchFields"] = array();
$tdatanas[".advSearchFields"][] = "id";
$tdatanas[".advSearchFields"][] = "nasname";
$tdatanas[".advSearchFields"][] = "shortname";
$tdatanas[".advSearchFields"][] = "type";
$tdatanas[".advSearchFields"][] = "ports";
$tdatanas[".advSearchFields"][] = "secret";
$tdatanas[".advSearchFields"][] = "server";
$tdatanas[".advSearchFields"][] = "community";
$tdatanas[".advSearchFields"][] = "description";

$tdatanas[".tableType"] = "list";

$tdatanas[".printerPageOrientation"] = 0;
$tdatanas[".nPrinterPageScale"] = 100;

$tdatanas[".nPrinterSplitRecords"] = 40;

$tdatanas[".nPrinterPDFSplitRecords"] = 40;



$tdatanas[".geocodingEnabled"] = false;





$tdatanas[".listGridLayout"] = 3;





// view page pdf

// print page pdf


$tdatanas[".pageSize"] = 20;

$tdatanas[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdatanas[".strOrderBy"] = $tstrOrderBy;

$tdatanas[".orderindexes"] = array();

$tdatanas[".sqlHead"] = "SELECT id,  	nasname,  	shortname,  	`type`,  	ports,  	secret,  	server,  	community,  	description";
$tdatanas[".sqlFrom"] = "FROM nas";
$tdatanas[".sqlWhereExpr"] = "";
$tdatanas[".sqlTail"] = "";











//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatanas[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatanas[".arrGroupsPerPage"] = $arrGPP;

$tdatanas[".highlightSearchResults"] = true;

$tableKeysnas = array();
$tableKeysnas[] = "id";
$tdatanas[".Keys"] = $tableKeysnas;

$tdatanas[".listFields"] = array();
$tdatanas[".listFields"][] = "id";
$tdatanas[".listFields"][] = "nasname";
$tdatanas[".listFields"][] = "shortname";
$tdatanas[".listFields"][] = "type";
$tdatanas[".listFields"][] = "ports";
$tdatanas[".listFields"][] = "secret";
$tdatanas[".listFields"][] = "server";
$tdatanas[".listFields"][] = "community";
$tdatanas[".listFields"][] = "description";

$tdatanas[".hideMobileList"] = array();


$tdatanas[".viewFields"] = array();
$tdatanas[".viewFields"][] = "id";
$tdatanas[".viewFields"][] = "nasname";
$tdatanas[".viewFields"][] = "shortname";
$tdatanas[".viewFields"][] = "type";
$tdatanas[".viewFields"][] = "ports";
$tdatanas[".viewFields"][] = "secret";
$tdatanas[".viewFields"][] = "server";
$tdatanas[".viewFields"][] = "community";
$tdatanas[".viewFields"][] = "description";

$tdatanas[".addFields"] = array();
$tdatanas[".addFields"][] = "nasname";
$tdatanas[".addFields"][] = "shortname";
$tdatanas[".addFields"][] = "type";
$tdatanas[".addFields"][] = "ports";
$tdatanas[".addFields"][] = "secret";
$tdatanas[".addFields"][] = "server";
$tdatanas[".addFields"][] = "community";
$tdatanas[".addFields"][] = "description";

$tdatanas[".masterListFields"] = array();
$tdatanas[".masterListFields"][] = "id";
$tdatanas[".masterListFields"][] = "nasname";
$tdatanas[".masterListFields"][] = "shortname";
$tdatanas[".masterListFields"][] = "type";
$tdatanas[".masterListFields"][] = "ports";
$tdatanas[".masterListFields"][] = "secret";
$tdatanas[".masterListFields"][] = "server";
$tdatanas[".masterListFields"][] = "community";
$tdatanas[".masterListFields"][] = "description";

$tdatanas[".inlineAddFields"] = array();
$tdatanas[".inlineAddFields"][] = "nasname";
$tdatanas[".inlineAddFields"][] = "shortname";
$tdatanas[".inlineAddFields"][] = "type";
$tdatanas[".inlineAddFields"][] = "ports";
$tdatanas[".inlineAddFields"][] = "secret";
$tdatanas[".inlineAddFields"][] = "server";
$tdatanas[".inlineAddFields"][] = "community";
$tdatanas[".inlineAddFields"][] = "description";

$tdatanas[".editFields"] = array();
$tdatanas[".editFields"][] = "nasname";
$tdatanas[".editFields"][] = "shortname";
$tdatanas[".editFields"][] = "type";
$tdatanas[".editFields"][] = "ports";
$tdatanas[".editFields"][] = "secret";
$tdatanas[".editFields"][] = "server";
$tdatanas[".editFields"][] = "community";
$tdatanas[".editFields"][] = "description";

$tdatanas[".inlineEditFields"] = array();
$tdatanas[".inlineEditFields"][] = "nasname";
$tdatanas[".inlineEditFields"][] = "shortname";
$tdatanas[".inlineEditFields"][] = "type";
$tdatanas[".inlineEditFields"][] = "ports";
$tdatanas[".inlineEditFields"][] = "secret";
$tdatanas[".inlineEditFields"][] = "server";
$tdatanas[".inlineEditFields"][] = "community";
$tdatanas[".inlineEditFields"][] = "description";

$tdatanas[".exportFields"] = array();
$tdatanas[".exportFields"][] = "id";
$tdatanas[".exportFields"][] = "nasname";
$tdatanas[".exportFields"][] = "shortname";
$tdatanas[".exportFields"][] = "type";
$tdatanas[".exportFields"][] = "ports";
$tdatanas[".exportFields"][] = "secret";
$tdatanas[".exportFields"][] = "server";
$tdatanas[".exportFields"][] = "community";
$tdatanas[".exportFields"][] = "description";

$tdatanas[".importFields"] = array();
$tdatanas[".importFields"][] = "id";
$tdatanas[".importFields"][] = "nasname";
$tdatanas[".importFields"][] = "shortname";
$tdatanas[".importFields"][] = "type";
$tdatanas[".importFields"][] = "ports";
$tdatanas[".importFields"][] = "secret";
$tdatanas[".importFields"][] = "server";
$tdatanas[".importFields"][] = "community";
$tdatanas[".importFields"][] = "description";

$tdatanas[".printFields"] = array();
$tdatanas[".printFields"][] = "id";
$tdatanas[".printFields"][] = "nasname";
$tdatanas[".printFields"][] = "shortname";
$tdatanas[".printFields"][] = "type";
$tdatanas[".printFields"][] = "ports";
$tdatanas[".printFields"][] = "secret";
$tdatanas[".printFields"][] = "server";
$tdatanas[".printFields"][] = "community";
$tdatanas[".printFields"][] = "description";

//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "nas";
	$fdata["Label"] = GetFieldLabel("nas","id");
	$fdata["FieldType"] = 3;

	
		$fdata["AutoInc"] = true;

	
			
		$fdata["bListPage"] = true;

	
	
	
	
		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "id";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdatanas["id"] = $fdata;
//	nasname
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "nasname";
	$fdata["GoodName"] = "nasname";
	$fdata["ownerTable"] = "nas";
	$fdata["Label"] = GetFieldLabel("nas","nasname");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "nasname";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "nasname";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=128";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdatanas["nasname"] = $fdata;
//	shortname
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "shortname";
	$fdata["GoodName"] = "shortname";
	$fdata["ownerTable"] = "nas";
	$fdata["Label"] = GetFieldLabel("nas","shortname");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "shortname";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "shortname";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=32";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdatanas["shortname"] = $fdata;
//	type
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "type";
	$fdata["GoodName"] = "type";
	$fdata["ownerTable"] = "nas";
	$fdata["Label"] = GetFieldLabel("nas","type");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "type";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`type`";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=30";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdatanas["type"] = $fdata;
//	ports
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "ports";
	$fdata["GoodName"] = "ports";
	$fdata["ownerTable"] = "nas";
	$fdata["Label"] = GetFieldLabel("nas","ports");
	$fdata["FieldType"] = 3;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "ports";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ports";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdatanas["ports"] = $fdata;
//	secret
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "secret";
	$fdata["GoodName"] = "secret";
	$fdata["ownerTable"] = "nas";
	$fdata["Label"] = GetFieldLabel("nas","secret");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "secret";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "secret";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=60";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdatanas["secret"] = $fdata;
//	server
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "server";
	$fdata["GoodName"] = "server";
	$fdata["ownerTable"] = "nas";
	$fdata["Label"] = GetFieldLabel("nas","server");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "server";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "server";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdatanas["server"] = $fdata;
//	community
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "community";
	$fdata["GoodName"] = "community";
	$fdata["ownerTable"] = "nas";
	$fdata["Label"] = GetFieldLabel("nas","community");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "community";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "community";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdatanas["community"] = $fdata;
//	description
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 9;
	$fdata["strName"] = "description";
	$fdata["GoodName"] = "description";
	$fdata["ownerTable"] = "nas";
	$fdata["Label"] = GetFieldLabel("nas","description");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "description";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "description";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=200";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdatanas["description"] = $fdata;


$tables_data["nas"]=&$tdatanas;
$field_labels["nas"] = &$fieldLabelsnas;
$fieldToolTips["nas"] = &$fieldToolTipsnas;
$page_titles["nas"] = &$pageTitlesnas;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["nas"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["nas"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_nas()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	nasname,  	shortname,  	`type`,  	ports,  	secret,  	server,  	community,  	description";
$proto0["m_strFrom"] = "FROM nas";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
$proto0["m_strTail"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "nas",
	"m_srcTableName" => "nas"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "nas";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "nasname",
	"m_strTable" => "nas",
	"m_srcTableName" => "nas"
));

$proto8["m_sql"] = "nasname";
$proto8["m_srcTableName"] = "nas";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "shortname",
	"m_strTable" => "nas",
	"m_srcTableName" => "nas"
));

$proto10["m_sql"] = "shortname";
$proto10["m_srcTableName"] = "nas";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "type",
	"m_strTable" => "nas",
	"m_srcTableName" => "nas"
));

$proto12["m_sql"] = "`type`";
$proto12["m_srcTableName"] = "nas";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "ports",
	"m_strTable" => "nas",
	"m_srcTableName" => "nas"
));

$proto14["m_sql"] = "ports";
$proto14["m_srcTableName"] = "nas";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
						$proto16=array();
			$obj = new SQLField(array(
	"m_strName" => "secret",
	"m_strTable" => "nas",
	"m_srcTableName" => "nas"
));

$proto16["m_sql"] = "secret";
$proto16["m_srcTableName"] = "nas";
$proto16["m_expr"]=$obj;
$proto16["m_alias"] = "";
$obj = new SQLFieldListItem($proto16);

$proto0["m_fieldlist"][]=$obj;
						$proto18=array();
			$obj = new SQLField(array(
	"m_strName" => "server",
	"m_strTable" => "nas",
	"m_srcTableName" => "nas"
));

$proto18["m_sql"] = "server";
$proto18["m_srcTableName"] = "nas";
$proto18["m_expr"]=$obj;
$proto18["m_alias"] = "";
$obj = new SQLFieldListItem($proto18);

$proto0["m_fieldlist"][]=$obj;
						$proto20=array();
			$obj = new SQLField(array(
	"m_strName" => "community",
	"m_strTable" => "nas",
	"m_srcTableName" => "nas"
));

$proto20["m_sql"] = "community";
$proto20["m_srcTableName"] = "nas";
$proto20["m_expr"]=$obj;
$proto20["m_alias"] = "";
$obj = new SQLFieldListItem($proto20);

$proto0["m_fieldlist"][]=$obj;
						$proto22=array();
			$obj = new SQLField(array(
	"m_strName" => "description",
	"m_strTable" => "nas",
	"m_srcTableName" => "nas"
));

$proto22["m_sql"] = "description";
$proto22["m_srcTableName"] = "nas";
$proto22["m_expr"]=$obj;
$proto22["m_alias"] = "";
$obj = new SQLFieldListItem($proto22);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto24=array();
$proto24["m_link"] = "SQLL_MAIN";
			$proto25=array();
$proto25["m_strName"] = "nas";
$proto25["m_srcTableName"] = "nas";
$proto25["m_columns"] = array();
$proto25["m_columns"][] = "id";
$proto25["m_columns"][] = "nasname";
$proto25["m_columns"][] = "shortname";
$proto25["m_columns"][] = "type";
$proto25["m_columns"][] = "ports";
$proto25["m_columns"][] = "secret";
$proto25["m_columns"][] = "server";
$proto25["m_columns"][] = "community";
$proto25["m_columns"][] = "description";
$obj = new SQLTable($proto25);

$proto24["m_table"] = $obj;
$proto24["m_sql"] = "nas";
$proto24["m_alias"] = "";
$proto24["m_srcTableName"] = "nas";
$proto26=array();
$proto26["m_sql"] = "";
$proto26["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto26["m_column"]=$obj;
$proto26["m_contained"] = array();
$proto26["m_strCase"] = "";
$proto26["m_havingmode"] = false;
$proto26["m_inBrackets"] = false;
$proto26["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto26);

$proto24["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto24);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="nas";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_nas = createSqlQuery_nas();


	
		;

									

$tdatanas[".sqlquery"] = $queryData_nas;

$tableEvents["nas"] = new eventsBase;
$tdatanas[".hasEvents"] = false;

?>