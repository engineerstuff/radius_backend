<?php
require_once(getabspath("classes/cipherer.php"));




$tdataradgroupcheck = array();
	$tdataradgroupcheck[".truncateText"] = true;
	$tdataradgroupcheck[".NumberOfChars"] = 80;
	$tdataradgroupcheck[".ShortName"] = "radgroupcheck";
	$tdataradgroupcheck[".OwnerID"] = "";
	$tdataradgroupcheck[".OriginalTable"] = "radgroupcheck";

//	field labels
$fieldLabelsradgroupcheck = array();
$fieldToolTipsradgroupcheck = array();
$pageTitlesradgroupcheck = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsradgroupcheck["English"] = array();
	$fieldToolTipsradgroupcheck["English"] = array();
	$pageTitlesradgroupcheck["English"] = array();
	$fieldLabelsradgroupcheck["English"]["id"] = "Id";
	$fieldToolTipsradgroupcheck["English"]["id"] = "";
	$fieldLabelsradgroupcheck["English"]["groupname"] = "Groupname";
	$fieldToolTipsradgroupcheck["English"]["groupname"] = "";
	$fieldLabelsradgroupcheck["English"]["attribute"] = "Attribute";
	$fieldToolTipsradgroupcheck["English"]["attribute"] = "";
	$fieldLabelsradgroupcheck["English"]["op"] = "Op";
	$fieldToolTipsradgroupcheck["English"]["op"] = "";
	$fieldLabelsradgroupcheck["English"]["value"] = "Value";
	$fieldToolTipsradgroupcheck["English"]["value"] = "";
	if (count($fieldToolTipsradgroupcheck["English"]))
		$tdataradgroupcheck[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsradgroupcheck[""] = array();
	$fieldToolTipsradgroupcheck[""] = array();
	$pageTitlesradgroupcheck[""] = array();
	if (count($fieldToolTipsradgroupcheck[""]))
		$tdataradgroupcheck[".isUseToolTips"] = true;
}


	$tdataradgroupcheck[".NCSearch"] = true;



$tdataradgroupcheck[".shortTableName"] = "radgroupcheck";
$tdataradgroupcheck[".nSecOptions"] = 0;
$tdataradgroupcheck[".recsPerRowPrint"] = 1;
$tdataradgroupcheck[".mainTableOwnerID"] = "";
$tdataradgroupcheck[".moveNext"] = 1;
$tdataradgroupcheck[".entityType"] = 0;

$tdataradgroupcheck[".strOriginalTableName"] = "radgroupcheck";

	



$tdataradgroupcheck[".showAddInPopup"] = false;

$tdataradgroupcheck[".showEditInPopup"] = false;

$tdataradgroupcheck[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdataradgroupcheck[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataradgroupcheck[".fieldsForRegister"] = array();

$tdataradgroupcheck[".listAjax"] = false;

	$tdataradgroupcheck[".audit"] = false;

	$tdataradgroupcheck[".locking"] = false;

$tdataradgroupcheck[".edit"] = true;
$tdataradgroupcheck[".afterEditAction"] = 1;
$tdataradgroupcheck[".closePopupAfterEdit"] = 1;
$tdataradgroupcheck[".afterEditActionDetTable"] = "";

$tdataradgroupcheck[".add"] = true;
$tdataradgroupcheck[".afterAddAction"] = 1;
$tdataradgroupcheck[".closePopupAfterAdd"] = 1;
$tdataradgroupcheck[".afterAddActionDetTable"] = "";

$tdataradgroupcheck[".list"] = true;

$tdataradgroupcheck[".view"] = true;

$tdataradgroupcheck[".import"] = true;

$tdataradgroupcheck[".exportTo"] = true;

$tdataradgroupcheck[".printFriendly"] = true;

$tdataradgroupcheck[".delete"] = true;

$tdataradgroupcheck[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdataradgroupcheck[".searchSaving"] = false;
//

$tdataradgroupcheck[".showSearchPanel"] = true;
		$tdataradgroupcheck[".flexibleSearch"] = true;

$tdataradgroupcheck[".isUseAjaxSuggest"] = true;

$tdataradgroupcheck[".rowHighlite"] = true;



$tdataradgroupcheck[".addPageEvents"] = false;

// use timepicker for search panel
$tdataradgroupcheck[".isUseTimeForSearch"] = false;





$tdataradgroupcheck[".allSearchFields"] = array();
$tdataradgroupcheck[".filterFields"] = array();
$tdataradgroupcheck[".requiredSearchFields"] = array();

$tdataradgroupcheck[".allSearchFields"][] = "id";
	$tdataradgroupcheck[".allSearchFields"][] = "groupname";
	$tdataradgroupcheck[".allSearchFields"][] = "attribute";
	$tdataradgroupcheck[".allSearchFields"][] = "op";
	$tdataradgroupcheck[".allSearchFields"][] = "value";
	

$tdataradgroupcheck[".googleLikeFields"] = array();
$tdataradgroupcheck[".googleLikeFields"][] = "id";
$tdataradgroupcheck[".googleLikeFields"][] = "groupname";
$tdataradgroupcheck[".googleLikeFields"][] = "attribute";
$tdataradgroupcheck[".googleLikeFields"][] = "op";
$tdataradgroupcheck[".googleLikeFields"][] = "value";


$tdataradgroupcheck[".advSearchFields"] = array();
$tdataradgroupcheck[".advSearchFields"][] = "id";
$tdataradgroupcheck[".advSearchFields"][] = "groupname";
$tdataradgroupcheck[".advSearchFields"][] = "attribute";
$tdataradgroupcheck[".advSearchFields"][] = "op";
$tdataradgroupcheck[".advSearchFields"][] = "value";

$tdataradgroupcheck[".tableType"] = "list";

$tdataradgroupcheck[".printerPageOrientation"] = 0;
$tdataradgroupcheck[".nPrinterPageScale"] = 100;

$tdataradgroupcheck[".nPrinterSplitRecords"] = 40;

$tdataradgroupcheck[".nPrinterPDFSplitRecords"] = 40;



$tdataradgroupcheck[".geocodingEnabled"] = false;





$tdataradgroupcheck[".listGridLayout"] = 3;





// view page pdf

// print page pdf


$tdataradgroupcheck[".pageSize"] = 20;

$tdataradgroupcheck[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataradgroupcheck[".strOrderBy"] = $tstrOrderBy;

$tdataradgroupcheck[".orderindexes"] = array();

$tdataradgroupcheck[".sqlHead"] = "SELECT id,  	groupname,  	attribute,  	op,  	`value`";
$tdataradgroupcheck[".sqlFrom"] = "FROM radgroupcheck";
$tdataradgroupcheck[".sqlWhereExpr"] = "";
$tdataradgroupcheck[".sqlTail"] = "";











//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataradgroupcheck[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataradgroupcheck[".arrGroupsPerPage"] = $arrGPP;

$tdataradgroupcheck[".highlightSearchResults"] = true;

$tableKeysradgroupcheck = array();
$tableKeysradgroupcheck[] = "id";
$tdataradgroupcheck[".Keys"] = $tableKeysradgroupcheck;

$tdataradgroupcheck[".listFields"] = array();
$tdataradgroupcheck[".listFields"][] = "id";
$tdataradgroupcheck[".listFields"][] = "groupname";
$tdataradgroupcheck[".listFields"][] = "attribute";
$tdataradgroupcheck[".listFields"][] = "op";
$tdataradgroupcheck[".listFields"][] = "value";

$tdataradgroupcheck[".hideMobileList"] = array();


$tdataradgroupcheck[".viewFields"] = array();
$tdataradgroupcheck[".viewFields"][] = "id";
$tdataradgroupcheck[".viewFields"][] = "groupname";
$tdataradgroupcheck[".viewFields"][] = "attribute";
$tdataradgroupcheck[".viewFields"][] = "op";
$tdataradgroupcheck[".viewFields"][] = "value";

$tdataradgroupcheck[".addFields"] = array();
$tdataradgroupcheck[".addFields"][] = "groupname";
$tdataradgroupcheck[".addFields"][] = "attribute";
$tdataradgroupcheck[".addFields"][] = "op";
$tdataradgroupcheck[".addFields"][] = "value";

$tdataradgroupcheck[".masterListFields"] = array();
$tdataradgroupcheck[".masterListFields"][] = "id";
$tdataradgroupcheck[".masterListFields"][] = "groupname";
$tdataradgroupcheck[".masterListFields"][] = "attribute";
$tdataradgroupcheck[".masterListFields"][] = "op";
$tdataradgroupcheck[".masterListFields"][] = "value";

$tdataradgroupcheck[".inlineAddFields"] = array();
$tdataradgroupcheck[".inlineAddFields"][] = "groupname";
$tdataradgroupcheck[".inlineAddFields"][] = "attribute";
$tdataradgroupcheck[".inlineAddFields"][] = "op";
$tdataradgroupcheck[".inlineAddFields"][] = "value";

$tdataradgroupcheck[".editFields"] = array();
$tdataradgroupcheck[".editFields"][] = "groupname";
$tdataradgroupcheck[".editFields"][] = "attribute";
$tdataradgroupcheck[".editFields"][] = "op";
$tdataradgroupcheck[".editFields"][] = "value";

$tdataradgroupcheck[".inlineEditFields"] = array();
$tdataradgroupcheck[".inlineEditFields"][] = "groupname";
$tdataradgroupcheck[".inlineEditFields"][] = "attribute";
$tdataradgroupcheck[".inlineEditFields"][] = "op";
$tdataradgroupcheck[".inlineEditFields"][] = "value";

$tdataradgroupcheck[".exportFields"] = array();
$tdataradgroupcheck[".exportFields"][] = "id";
$tdataradgroupcheck[".exportFields"][] = "groupname";
$tdataradgroupcheck[".exportFields"][] = "attribute";
$tdataradgroupcheck[".exportFields"][] = "op";
$tdataradgroupcheck[".exportFields"][] = "value";

$tdataradgroupcheck[".importFields"] = array();
$tdataradgroupcheck[".importFields"][] = "id";
$tdataradgroupcheck[".importFields"][] = "groupname";
$tdataradgroupcheck[".importFields"][] = "attribute";
$tdataradgroupcheck[".importFields"][] = "op";
$tdataradgroupcheck[".importFields"][] = "value";

$tdataradgroupcheck[".printFields"] = array();
$tdataradgroupcheck[".printFields"][] = "id";
$tdataradgroupcheck[".printFields"][] = "groupname";
$tdataradgroupcheck[".printFields"][] = "attribute";
$tdataradgroupcheck[".printFields"][] = "op";
$tdataradgroupcheck[".printFields"][] = "value";

//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "radgroupcheck";
	$fdata["Label"] = GetFieldLabel("radgroupcheck","id");
	$fdata["FieldType"] = 3;

	
		$fdata["AutoInc"] = true;

	
			
		$fdata["bListPage"] = true;

	
	
	
	
		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "id";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradgroupcheck["id"] = $fdata;
//	groupname
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "groupname";
	$fdata["GoodName"] = "groupname";
	$fdata["ownerTable"] = "radgroupcheck";
	$fdata["Label"] = GetFieldLabel("radgroupcheck","groupname");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "groupname";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "groupname";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradgroupcheck["groupname"] = $fdata;
//	attribute
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "attribute";
	$fdata["GoodName"] = "attribute";
	$fdata["ownerTable"] = "radgroupcheck";
	$fdata["Label"] = GetFieldLabel("radgroupcheck","attribute");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "attribute";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "attribute";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradgroupcheck["attribute"] = $fdata;
//	op
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "op";
	$fdata["GoodName"] = "op";
	$fdata["ownerTable"] = "radgroupcheck";
	$fdata["Label"] = GetFieldLabel("radgroupcheck","op");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "op";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "op";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=2";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradgroupcheck["op"] = $fdata;
//	value
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "value";
	$fdata["GoodName"] = "value";
	$fdata["ownerTable"] = "radgroupcheck";
	$fdata["Label"] = GetFieldLabel("radgroupcheck","value");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "value";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`value`";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=253";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradgroupcheck["value"] = $fdata;


$tables_data["radgroupcheck"]=&$tdataradgroupcheck;
$field_labels["radgroupcheck"] = &$fieldLabelsradgroupcheck;
$fieldToolTips["radgroupcheck"] = &$fieldToolTipsradgroupcheck;
$page_titles["radgroupcheck"] = &$pageTitlesradgroupcheck;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["radgroupcheck"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["radgroupcheck"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_radgroupcheck()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	groupname,  	attribute,  	op,  	`value`";
$proto0["m_strFrom"] = "FROM radgroupcheck";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
$proto0["m_strTail"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "radgroupcheck",
	"m_srcTableName" => "radgroupcheck"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "radgroupcheck";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "groupname",
	"m_strTable" => "radgroupcheck",
	"m_srcTableName" => "radgroupcheck"
));

$proto8["m_sql"] = "groupname";
$proto8["m_srcTableName"] = "radgroupcheck";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "attribute",
	"m_strTable" => "radgroupcheck",
	"m_srcTableName" => "radgroupcheck"
));

$proto10["m_sql"] = "attribute";
$proto10["m_srcTableName"] = "radgroupcheck";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "op",
	"m_strTable" => "radgroupcheck",
	"m_srcTableName" => "radgroupcheck"
));

$proto12["m_sql"] = "op";
$proto12["m_srcTableName"] = "radgroupcheck";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "value",
	"m_strTable" => "radgroupcheck",
	"m_srcTableName" => "radgroupcheck"
));

$proto14["m_sql"] = "`value`";
$proto14["m_srcTableName"] = "radgroupcheck";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto16=array();
$proto16["m_link"] = "SQLL_MAIN";
			$proto17=array();
$proto17["m_strName"] = "radgroupcheck";
$proto17["m_srcTableName"] = "radgroupcheck";
$proto17["m_columns"] = array();
$proto17["m_columns"][] = "id";
$proto17["m_columns"][] = "groupname";
$proto17["m_columns"][] = "attribute";
$proto17["m_columns"][] = "op";
$proto17["m_columns"][] = "value";
$obj = new SQLTable($proto17);

$proto16["m_table"] = $obj;
$proto16["m_sql"] = "radgroupcheck";
$proto16["m_alias"] = "";
$proto16["m_srcTableName"] = "radgroupcheck";
$proto18=array();
$proto18["m_sql"] = "";
$proto18["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto18["m_column"]=$obj;
$proto18["m_contained"] = array();
$proto18["m_strCase"] = "";
$proto18["m_havingmode"] = false;
$proto18["m_inBrackets"] = false;
$proto18["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto18);

$proto16["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto16);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="radgroupcheck";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_radgroupcheck = createSqlQuery_radgroupcheck();


	
		;

					

$tdataradgroupcheck[".sqlquery"] = $queryData_radgroupcheck;

$tableEvents["radgroupcheck"] = new eventsBase;
$tdataradgroupcheck[".hasEvents"] = false;

?>