<?php
require_once(getabspath("classes/cipherer.php"));




$tdataadmins = array();
	$tdataadmins[".truncateText"] = true;
	$tdataadmins[".NumberOfChars"] = 80;
	$tdataadmins[".ShortName"] = "admins";
	$tdataadmins[".OwnerID"] = "";
	$tdataadmins[".OriginalTable"] = "admins";

//	field labels
$fieldLabelsadmins = array();
$fieldToolTipsadmins = array();
$pageTitlesadmins = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsadmins["English"] = array();
	$fieldToolTipsadmins["English"] = array();
	$pageTitlesadmins["English"] = array();
	$fieldLabelsadmins["English"]["id"] = "Id";
	$fieldToolTipsadmins["English"]["id"] = "";
	$fieldLabelsadmins["English"]["username"] = "Username";
	$fieldToolTipsadmins["English"]["username"] = "";
	$fieldLabelsadmins["English"]["firstname"] = "Firstname";
	$fieldToolTipsadmins["English"]["firstname"] = "";
	$fieldLabelsadmins["English"]["lastname"] = "Lastname";
	$fieldToolTipsadmins["English"]["lastname"] = "";
	$fieldLabelsadmins["English"]["password"] = "Password";
	$fieldToolTipsadmins["English"]["password"] = "";
	if (count($fieldToolTipsadmins["English"]))
		$tdataadmins[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsadmins[""] = array();
	$fieldToolTipsadmins[""] = array();
	$pageTitlesadmins[""] = array();
	if (count($fieldToolTipsadmins[""]))
		$tdataadmins[".isUseToolTips"] = true;
}


	$tdataadmins[".NCSearch"] = true;



$tdataadmins[".shortTableName"] = "admins";
$tdataadmins[".nSecOptions"] = 0;
$tdataadmins[".recsPerRowPrint"] = 1;
$tdataadmins[".mainTableOwnerID"] = "";
$tdataadmins[".moveNext"] = 1;
$tdataadmins[".entityType"] = 0;

$tdataadmins[".strOriginalTableName"] = "admins";

	



$tdataadmins[".showAddInPopup"] = false;

$tdataadmins[".showEditInPopup"] = false;

$tdataadmins[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdataadmins[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataadmins[".fieldsForRegister"] = array();

$tdataadmins[".listAjax"] = false;

	$tdataadmins[".audit"] = false;

	$tdataadmins[".locking"] = false;

$tdataadmins[".edit"] = true;
$tdataadmins[".afterEditAction"] = 1;
$tdataadmins[".closePopupAfterEdit"] = 1;
$tdataadmins[".afterEditActionDetTable"] = "";

$tdataadmins[".add"] = true;
$tdataadmins[".afterAddAction"] = 1;
$tdataadmins[".closePopupAfterAdd"] = 1;
$tdataadmins[".afterAddActionDetTable"] = "";

$tdataadmins[".list"] = true;

$tdataadmins[".view"] = true;

$tdataadmins[".import"] = true;

$tdataadmins[".exportTo"] = true;

$tdataadmins[".printFriendly"] = true;

$tdataadmins[".delete"] = true;

$tdataadmins[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdataadmins[".searchSaving"] = false;
//

$tdataadmins[".showSearchPanel"] = true;
		$tdataadmins[".flexibleSearch"] = true;

$tdataadmins[".isUseAjaxSuggest"] = true;

$tdataadmins[".rowHighlite"] = true;



$tdataadmins[".addPageEvents"] = false;

// use timepicker for search panel
$tdataadmins[".isUseTimeForSearch"] = false;



$tdataadmins[".badgeColor"] = "778899";


$tdataadmins[".allSearchFields"] = array();
$tdataadmins[".filterFields"] = array();
$tdataadmins[".requiredSearchFields"] = array();

$tdataadmins[".allSearchFields"][] = "id";
	$tdataadmins[".allSearchFields"][] = "username";
	$tdataadmins[".allSearchFields"][] = "firstname";
	$tdataadmins[".allSearchFields"][] = "lastname";
	$tdataadmins[".allSearchFields"][] = "password";
	

$tdataadmins[".googleLikeFields"] = array();
$tdataadmins[".googleLikeFields"][] = "id";
$tdataadmins[".googleLikeFields"][] = "username";
$tdataadmins[".googleLikeFields"][] = "firstname";
$tdataadmins[".googleLikeFields"][] = "lastname";
$tdataadmins[".googleLikeFields"][] = "password";


$tdataadmins[".advSearchFields"] = array();
$tdataadmins[".advSearchFields"][] = "id";
$tdataadmins[".advSearchFields"][] = "username";
$tdataadmins[".advSearchFields"][] = "firstname";
$tdataadmins[".advSearchFields"][] = "lastname";
$tdataadmins[".advSearchFields"][] = "password";

$tdataadmins[".tableType"] = "list";

$tdataadmins[".printerPageOrientation"] = 0;
$tdataadmins[".nPrinterPageScale"] = 100;

$tdataadmins[".nPrinterSplitRecords"] = 40;

$tdataadmins[".nPrinterPDFSplitRecords"] = 40;



$tdataadmins[".geocodingEnabled"] = false;





$tdataadmins[".listGridLayout"] = 3;





// view page pdf

// print page pdf


$tdataadmins[".pageSize"] = 20;

$tdataadmins[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataadmins[".strOrderBy"] = $tstrOrderBy;

$tdataadmins[".orderindexes"] = array();

$tdataadmins[".sqlHead"] = "SELECT id,  	username,  	firstname,  	lastname,  	password";
$tdataadmins[".sqlFrom"] = "FROM admins";
$tdataadmins[".sqlWhereExpr"] = "";
$tdataadmins[".sqlTail"] = "";











//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataadmins[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataadmins[".arrGroupsPerPage"] = $arrGPP;

$tdataadmins[".highlightSearchResults"] = true;

$tableKeysadmins = array();
$tableKeysadmins[] = "id";
$tdataadmins[".Keys"] = $tableKeysadmins;

$tdataadmins[".listFields"] = array();
$tdataadmins[".listFields"][] = "id";
$tdataadmins[".listFields"][] = "username";
$tdataadmins[".listFields"][] = "firstname";
$tdataadmins[".listFields"][] = "lastname";
$tdataadmins[".listFields"][] = "password";

$tdataadmins[".hideMobileList"] = array();


$tdataadmins[".viewFields"] = array();
$tdataadmins[".viewFields"][] = "id";
$tdataadmins[".viewFields"][] = "username";
$tdataadmins[".viewFields"][] = "firstname";
$tdataadmins[".viewFields"][] = "lastname";
$tdataadmins[".viewFields"][] = "password";

$tdataadmins[".addFields"] = array();
$tdataadmins[".addFields"][] = "username";
$tdataadmins[".addFields"][] = "firstname";
$tdataadmins[".addFields"][] = "lastname";
$tdataadmins[".addFields"][] = "password";

$tdataadmins[".masterListFields"] = array();
$tdataadmins[".masterListFields"][] = "id";
$tdataadmins[".masterListFields"][] = "username";
$tdataadmins[".masterListFields"][] = "firstname";
$tdataadmins[".masterListFields"][] = "lastname";
$tdataadmins[".masterListFields"][] = "password";

$tdataadmins[".inlineAddFields"] = array();
$tdataadmins[".inlineAddFields"][] = "username";
$tdataadmins[".inlineAddFields"][] = "firstname";
$tdataadmins[".inlineAddFields"][] = "lastname";
$tdataadmins[".inlineAddFields"][] = "password";

$tdataadmins[".editFields"] = array();
$tdataadmins[".editFields"][] = "username";
$tdataadmins[".editFields"][] = "firstname";
$tdataadmins[".editFields"][] = "lastname";
$tdataadmins[".editFields"][] = "password";

$tdataadmins[".inlineEditFields"] = array();
$tdataadmins[".inlineEditFields"][] = "username";
$tdataadmins[".inlineEditFields"][] = "firstname";
$tdataadmins[".inlineEditFields"][] = "lastname";
$tdataadmins[".inlineEditFields"][] = "password";

$tdataadmins[".exportFields"] = array();
$tdataadmins[".exportFields"][] = "id";
$tdataadmins[".exportFields"][] = "username";
$tdataadmins[".exportFields"][] = "firstname";
$tdataadmins[".exportFields"][] = "lastname";
$tdataadmins[".exportFields"][] = "password";

$tdataadmins[".importFields"] = array();
$tdataadmins[".importFields"][] = "id";
$tdataadmins[".importFields"][] = "username";
$tdataadmins[".importFields"][] = "firstname";
$tdataadmins[".importFields"][] = "lastname";
$tdataadmins[".importFields"][] = "password";

$tdataadmins[".printFields"] = array();
$tdataadmins[".printFields"][] = "id";
$tdataadmins[".printFields"][] = "username";
$tdataadmins[".printFields"][] = "firstname";
$tdataadmins[".printFields"][] = "lastname";
$tdataadmins[".printFields"][] = "password";

//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "admins";
	$fdata["Label"] = GetFieldLabel("admins","id");
	$fdata["FieldType"] = 3;

	
		$fdata["AutoInc"] = true;

	
			
		$fdata["bListPage"] = true;

	
	
	
	
		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "id";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataadmins["id"] = $fdata;
//	username
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "username";
	$fdata["GoodName"] = "username";
	$fdata["ownerTable"] = "admins";
	$fdata["Label"] = GetFieldLabel("admins","username");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "username";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "username";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=30";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataadmins["username"] = $fdata;
//	firstname
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "firstname";
	$fdata["GoodName"] = "firstname";
	$fdata["ownerTable"] = "admins";
	$fdata["Label"] = GetFieldLabel("admins","firstname");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "firstname";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "firstname";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=30";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataadmins["firstname"] = $fdata;
//	lastname
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "lastname";
	$fdata["GoodName"] = "lastname";
	$fdata["ownerTable"] = "admins";
	$fdata["Label"] = GetFieldLabel("admins","lastname");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "lastname";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "lastname";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=30";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataadmins["lastname"] = $fdata;
//	password
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "password";
	$fdata["GoodName"] = "password";
	$fdata["ownerTable"] = "admins";
	$fdata["Label"] = GetFieldLabel("admins","password");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "password";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "password";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataadmins["password"] = $fdata;


$tables_data["admins"]=&$tdataadmins;
$field_labels["admins"] = &$fieldLabelsadmins;
$fieldToolTips["admins"] = &$fieldToolTipsadmins;
$page_titles["admins"] = &$pageTitlesadmins;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["admins"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["admins"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_admins()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	username,  	firstname,  	lastname,  	password";
$proto0["m_strFrom"] = "FROM admins";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
$proto0["m_strTail"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "admins",
	"m_srcTableName" => "admins"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "admins";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "username",
	"m_strTable" => "admins",
	"m_srcTableName" => "admins"
));

$proto8["m_sql"] = "username";
$proto8["m_srcTableName"] = "admins";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "firstname",
	"m_strTable" => "admins",
	"m_srcTableName" => "admins"
));

$proto10["m_sql"] = "firstname";
$proto10["m_srcTableName"] = "admins";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "lastname",
	"m_strTable" => "admins",
	"m_srcTableName" => "admins"
));

$proto12["m_sql"] = "lastname";
$proto12["m_srcTableName"] = "admins";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "password",
	"m_strTable" => "admins",
	"m_srcTableName" => "admins"
));

$proto14["m_sql"] = "password";
$proto14["m_srcTableName"] = "admins";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto16=array();
$proto16["m_link"] = "SQLL_MAIN";
			$proto17=array();
$proto17["m_strName"] = "admins";
$proto17["m_srcTableName"] = "admins";
$proto17["m_columns"] = array();
$proto17["m_columns"][] = "id";
$proto17["m_columns"][] = "username";
$proto17["m_columns"][] = "firstname";
$proto17["m_columns"][] = "lastname";
$proto17["m_columns"][] = "password";
$obj = new SQLTable($proto17);

$proto16["m_table"] = $obj;
$proto16["m_sql"] = "admins";
$proto16["m_alias"] = "";
$proto16["m_srcTableName"] = "admins";
$proto18=array();
$proto18["m_sql"] = "";
$proto18["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto18["m_column"]=$obj;
$proto18["m_contained"] = array();
$proto18["m_strCase"] = "";
$proto18["m_havingmode"] = false;
$proto18["m_inBrackets"] = false;
$proto18["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto18);

$proto16["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto16);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="admins";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_admins = createSqlQuery_admins();


	
		;

					

$tdataadmins[".sqlquery"] = $queryData_admins;

$tableEvents["admins"] = new eventsBase;
$tdataadmins[".hasEvents"] = false;

?>