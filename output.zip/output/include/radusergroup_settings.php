<?php
require_once(getabspath("classes/cipherer.php"));




$tdataradusergroup = array();
	$tdataradusergroup[".truncateText"] = true;
	$tdataradusergroup[".NumberOfChars"] = 80;
	$tdataradusergroup[".ShortName"] = "radusergroup";
	$tdataradusergroup[".OwnerID"] = "";
	$tdataradusergroup[".OriginalTable"] = "radusergroup";

//	field labels
$fieldLabelsradusergroup = array();
$fieldToolTipsradusergroup = array();
$pageTitlesradusergroup = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsradusergroup["English"] = array();
	$fieldToolTipsradusergroup["English"] = array();
	$pageTitlesradusergroup["English"] = array();
	$fieldLabelsradusergroup["English"]["username"] = "Username";
	$fieldToolTipsradusergroup["English"]["username"] = "";
	$fieldLabelsradusergroup["English"]["groupname"] = "Groupname";
	$fieldToolTipsradusergroup["English"]["groupname"] = "";
	$fieldLabelsradusergroup["English"]["priority"] = "Priority";
	$fieldToolTipsradusergroup["English"]["priority"] = "";
	if (count($fieldToolTipsradusergroup["English"]))
		$tdataradusergroup[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsradusergroup[""] = array();
	$fieldToolTipsradusergroup[""] = array();
	$pageTitlesradusergroup[""] = array();
	if (count($fieldToolTipsradusergroup[""]))
		$tdataradusergroup[".isUseToolTips"] = true;
}


	$tdataradusergroup[".NCSearch"] = true;



$tdataradusergroup[".shortTableName"] = "radusergroup";
$tdataradusergroup[".nSecOptions"] = 0;
$tdataradusergroup[".recsPerRowPrint"] = 1;
$tdataradusergroup[".mainTableOwnerID"] = "";
$tdataradusergroup[".moveNext"] = 1;
$tdataradusergroup[".entityType"] = 0;

$tdataradusergroup[".strOriginalTableName"] = "radusergroup";

	



$tdataradusergroup[".showAddInPopup"] = false;

$tdataradusergroup[".showEditInPopup"] = false;

$tdataradusergroup[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdataradusergroup[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataradusergroup[".fieldsForRegister"] = array();

$tdataradusergroup[".listAjax"] = false;

	$tdataradusergroup[".audit"] = false;

	$tdataradusergroup[".locking"] = false;



$tdataradusergroup[".list"] = true;


$tdataradusergroup[".import"] = true;

$tdataradusergroup[".exportTo"] = true;

$tdataradusergroup[".printFriendly"] = true;


$tdataradusergroup[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdataradusergroup[".searchSaving"] = false;
//

$tdataradusergroup[".showSearchPanel"] = true;
		$tdataradusergroup[".flexibleSearch"] = true;

$tdataradusergroup[".isUseAjaxSuggest"] = true;

$tdataradusergroup[".rowHighlite"] = true;



$tdataradusergroup[".addPageEvents"] = false;

// use timepicker for search panel
$tdataradusergroup[".isUseTimeForSearch"] = false;





$tdataradusergroup[".allSearchFields"] = array();
$tdataradusergroup[".filterFields"] = array();
$tdataradusergroup[".requiredSearchFields"] = array();

$tdataradusergroup[".allSearchFields"][] = "username";
	$tdataradusergroup[".allSearchFields"][] = "groupname";
	$tdataradusergroup[".allSearchFields"][] = "priority";
	

$tdataradusergroup[".googleLikeFields"] = array();
$tdataradusergroup[".googleLikeFields"][] = "username";
$tdataradusergroup[".googleLikeFields"][] = "groupname";
$tdataradusergroup[".googleLikeFields"][] = "priority";


$tdataradusergroup[".advSearchFields"] = array();
$tdataradusergroup[".advSearchFields"][] = "username";
$tdataradusergroup[".advSearchFields"][] = "groupname";
$tdataradusergroup[".advSearchFields"][] = "priority";

$tdataradusergroup[".tableType"] = "list";

$tdataradusergroup[".printerPageOrientation"] = 0;
$tdataradusergroup[".nPrinterPageScale"] = 100;

$tdataradusergroup[".nPrinterSplitRecords"] = 40;

$tdataradusergroup[".nPrinterPDFSplitRecords"] = 40;



$tdataradusergroup[".geocodingEnabled"] = false;





$tdataradusergroup[".listGridLayout"] = 3;





// view page pdf

// print page pdf


$tdataradusergroup[".pageSize"] = 20;

$tdataradusergroup[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataradusergroup[".strOrderBy"] = $tstrOrderBy;

$tdataradusergroup[".orderindexes"] = array();

$tdataradusergroup[".sqlHead"] = "SELECT username,  	groupname,  	priority";
$tdataradusergroup[".sqlFrom"] = "FROM radusergroup";
$tdataradusergroup[".sqlWhereExpr"] = "";
$tdataradusergroup[".sqlTail"] = "";











//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataradusergroup[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataradusergroup[".arrGroupsPerPage"] = $arrGPP;

$tdataradusergroup[".highlightSearchResults"] = true;

$tableKeysradusergroup = array();
$tdataradusergroup[".Keys"] = $tableKeysradusergroup;

$tdataradusergroup[".listFields"] = array();
$tdataradusergroup[".listFields"][] = "username";
$tdataradusergroup[".listFields"][] = "groupname";
$tdataradusergroup[".listFields"][] = "priority";

$tdataradusergroup[".hideMobileList"] = array();


$tdataradusergroup[".viewFields"] = array();
$tdataradusergroup[".viewFields"][] = "username";
$tdataradusergroup[".viewFields"][] = "groupname";
$tdataradusergroup[".viewFields"][] = "priority";

$tdataradusergroup[".addFields"] = array();
$tdataradusergroup[".addFields"][] = "username";
$tdataradusergroup[".addFields"][] = "groupname";
$tdataradusergroup[".addFields"][] = "priority";

$tdataradusergroup[".masterListFields"] = array();
$tdataradusergroup[".masterListFields"][] = "username";
$tdataradusergroup[".masterListFields"][] = "groupname";
$tdataradusergroup[".masterListFields"][] = "priority";

$tdataradusergroup[".inlineAddFields"] = array();
$tdataradusergroup[".inlineAddFields"][] = "username";
$tdataradusergroup[".inlineAddFields"][] = "groupname";
$tdataradusergroup[".inlineAddFields"][] = "priority";

$tdataradusergroup[".editFields"] = array();
$tdataradusergroup[".editFields"][] = "username";
$tdataradusergroup[".editFields"][] = "groupname";
$tdataradusergroup[".editFields"][] = "priority";

$tdataradusergroup[".inlineEditFields"] = array();
$tdataradusergroup[".inlineEditFields"][] = "username";
$tdataradusergroup[".inlineEditFields"][] = "groupname";
$tdataradusergroup[".inlineEditFields"][] = "priority";

$tdataradusergroup[".exportFields"] = array();
$tdataradusergroup[".exportFields"][] = "username";
$tdataradusergroup[".exportFields"][] = "groupname";
$tdataradusergroup[".exportFields"][] = "priority";

$tdataradusergroup[".importFields"] = array();
$tdataradusergroup[".importFields"][] = "username";
$tdataradusergroup[".importFields"][] = "groupname";
$tdataradusergroup[".importFields"][] = "priority";

$tdataradusergroup[".printFields"] = array();
$tdataradusergroup[".printFields"][] = "username";
$tdataradusergroup[".printFields"][] = "groupname";
$tdataradusergroup[".printFields"][] = "priority";

//	username
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "username";
	$fdata["GoodName"] = "username";
	$fdata["ownerTable"] = "radusergroup";
	$fdata["Label"] = GetFieldLabel("radusergroup","username");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "username";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "username";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradusergroup["username"] = $fdata;
//	groupname
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "groupname";
	$fdata["GoodName"] = "groupname";
	$fdata["ownerTable"] = "radusergroup";
	$fdata["Label"] = GetFieldLabel("radusergroup","groupname");
	$fdata["FieldType"] = 200;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "groupname";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "groupname";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=64";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradusergroup["groupname"] = $fdata;
//	priority
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "priority";
	$fdata["GoodName"] = "priority";
	$fdata["ownerTable"] = "radusergroup";
	$fdata["Label"] = GetFieldLabel("radusergroup","priority");
	$fdata["FieldType"] = 3;

	
	
	
			
		$fdata["bListPage"] = true;

		$fdata["bAddPage"] = true;

		$fdata["bInlineAdd"] = true;

		$fdata["bEditPage"] = true;

		$fdata["bInlineEdit"] = true;

		$fdata["bViewPage"] = true;

		$fdata["bAdvancedSearch"] = true;

		$fdata["bPrinterPage"] = true;

		$fdata["bExportPage"] = true;

		$fdata["strField"] = "priority";

		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "priority";

	
	
				$fdata["FieldPermissions"] = true;

				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "number";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings




	$tdataradusergroup["priority"] = $fdata;


$tables_data["radusergroup"]=&$tdataradusergroup;
$field_labels["radusergroup"] = &$fieldLabelsradusergroup;
$fieldToolTips["radusergroup"] = &$fieldToolTipsradusergroup;
$page_titles["radusergroup"] = &$pageTitlesradusergroup;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["radusergroup"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["radusergroup"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_radusergroup()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "username,  	groupname,  	priority";
$proto0["m_strFrom"] = "FROM radusergroup";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
$proto0["m_strTail"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "username",
	"m_strTable" => "radusergroup",
	"m_srcTableName" => "radusergroup"
));

$proto6["m_sql"] = "username";
$proto6["m_srcTableName"] = "radusergroup";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "groupname",
	"m_strTable" => "radusergroup",
	"m_srcTableName" => "radusergroup"
));

$proto8["m_sql"] = "groupname";
$proto8["m_srcTableName"] = "radusergroup";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "priority",
	"m_strTable" => "radusergroup",
	"m_srcTableName" => "radusergroup"
));

$proto10["m_sql"] = "priority";
$proto10["m_srcTableName"] = "radusergroup";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto12=array();
$proto12["m_link"] = "SQLL_MAIN";
			$proto13=array();
$proto13["m_strName"] = "radusergroup";
$proto13["m_srcTableName"] = "radusergroup";
$proto13["m_columns"] = array();
$proto13["m_columns"][] = "username";
$proto13["m_columns"][] = "groupname";
$proto13["m_columns"][] = "priority";
$obj = new SQLTable($proto13);

$proto12["m_table"] = $obj;
$proto12["m_sql"] = "radusergroup";
$proto12["m_alias"] = "";
$proto12["m_srcTableName"] = "radusergroup";
$proto14=array();
$proto14["m_sql"] = "";
$proto14["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto14["m_column"]=$obj;
$proto14["m_contained"] = array();
$proto14["m_strCase"] = "";
$proto14["m_havingmode"] = false;
$proto14["m_inBrackets"] = false;
$proto14["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto14);

$proto12["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto12);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="radusergroup";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_radusergroup = createSqlQuery_radusergroup();


	
		;

			

$tdataradusergroup[".sqlquery"] = $queryData_radusergroup;

$tableEvents["radusergroup"] = new eventsBase;
$tdataradusergroup[".hasEvents"] = false;

?>